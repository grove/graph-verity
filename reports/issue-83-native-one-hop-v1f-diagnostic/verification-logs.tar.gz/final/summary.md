# Pre-LLM verification

Commit: `d3428e1b1af32b42f9a018cb83ee4aa61c14e89b`

Executable oracle checks: **38 / 38**.

Recorded abstention cases: **8**; not model-tested and excluded from executable accuracy.

Formatting, Clippy, Rust tests, source hashes, byte-rebuild, independent gold, schema parity, deterministic catalog, manual/fixture evidence, and rejection demos passed.

No language model was run. Gold is machine-authored and human-review pending. No independent locked holdout or target-device parser measurement has been completed. This is engineering readiness for a local parser experiment, not a Phase 0 go decision.
