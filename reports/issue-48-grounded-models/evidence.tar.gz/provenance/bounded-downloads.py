import concurrent.futures,hashlib,json,os,time,urllib.request
from pathlib import Path
cfg=json.loads(Path('configs/grounded-models-v1.json').read_text());root=Path('artifacts/issue-48/upstream')
completed={}
for line in Path('artifacts/issue-48/resume-downloads.log').read_text().splitlines():
 if ' complete ' in line:
  k,n,a,b,*_=line.split();completed.setdefault((k,n),[]).append((int(a),int(b)+1))
prefix={('qwen35','model.safetensors-00002-of-00004.safetensors'):159383552,('gemma4','model.safetensors'):3191865344}
jobs=[];outputs={};started=time.monotonic()
for key,c in cfg['candidates'].items():
 for name,f in c['files'].items():
  if not name.endswith('.safetensors'):continue
  path=root/key/name
  if path.exists():continue
  part=path.with_suffix('.partial');fd=os.open(part,os.O_CREAT|os.O_RDWR,0o644);outputs[path]=(part,fd,f)
  covered=sorted([(0,prefix.get((key,name),0)),*completed.get((key,name),[])])
  cursor=0;missing=[]
  for a,b in covered:
   if a>cursor:missing.append((cursor,a))
   cursor=max(cursor,b)
  if cursor<f['bytes']:missing.append((cursor,f['bytes']))
  for start,end in missing:
   for a in range(start,end,8*1024*1024):jobs.append((key,c,name,fd,a,min(a+8*1024*1024,end)-1,f['bytes']))
print('Remaining bounded ranges',len(jobs),'bytes',sum(j[5]-j[4]+1 for j in jobs),flush=True)
def transfer(job):
 key,c,name,fd,a,b,total=job
 for attempt in range(12):
  begun=time.monotonic();position=a
  try:
   url=f"https://huggingface.co/{c['repo']}/resolve/{c['revision']}/{name}?download=true&range={a}-{b}&attempt={attempt}"
   req=urllib.request.Request(url,headers={'Range':f'bytes={a}-{b}'})
   with urllib.request.urlopen(req,timeout=15) as response:
    assert response.status==206 and response.headers['Content-Range']==f'bytes {a}-{b}/{total}'
    while position<=b:
     if time.monotonic()-begun>45:raise TimeoutError('range wall deadline')
     block=response.read1(min(128*1024,b+1-position))
     if not block:raise EOFError('short body')
     assert os.pwrite(fd,block,position)==len(block)
     position+=len(block)
   print('complete',key,name,a,b,round(time.monotonic()-started,1),flush=True);return
  except Exception as error:
   print('transfer error',key,name,a,b,attempt,type(error).__name__,flush=True)
 raise RuntimeError((key,name,a,b,'exhausted acquisition attempts'))
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:list(pool.map(transfer,jobs))
for path,(part,fd,f) in outputs.items():
 os.fsync(fd);os.close(fd)
 with part.open('rb') as stream:actual=hashlib.file_digest(stream,'sha256').hexdigest()
 assert actual==f['sha256'] and part.stat().st_size==f['bytes'],(path,actual)
 part.rename(path);print('VERIFIED',path,f['bytes'],actual,flush=True)
