from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
sys.path.insert(0,'tools')
from grounded_models import ASSETS,CONFIG,ROOT,config,dump,sha,verify_freeze
cfg=config();freeze=ASSETS/'locked-cpu-v1'
while not all((ASSETS/f'{key}-receipt.json').exists() for key in cfg['candidates']):time.sleep(10)
verify_freeze(freeze)
receipts={key:json.loads((ASSETS/f'{key}-receipt.json').read_text()) for key in cfg['candidates']}
for binary in ['llama-server','llama-quantize','test-gbnf-validator']:
 name='build/bin/'+binary
 assert receipts['qwen35']['files'][name]['sha256']==receipts['gemma4']['files'][name]['sha256'],name
operator={'version':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'config_sha256':sha(CONFIG),'freeze_sha256':sha(freeze/'checksums.json'),'operator_script_sha256':sha(Path(__file__)),
 'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'order':['qwen35','gemma4'],
 'conditions':'sequential model runs; native download, conversion and quantization complete before inference; OS page cache not evicted',
 'native_verification':{},'runs':{},'holdout_accessed':False}
for key,c in cfg['candidates'].items():
 actual={}
 for name,identity in c['files'].items():
  path=ASSETS/'upstream'/key/name;digest=sha(path)
  assert digest==identity['sha256'] and path.stat().st_size==identity['bytes'],name
  actual[name]={'sha256':digest,'bytes':path.stat().st_size}
 operator['native_verification'][key]={'repo':c['repo'],'revision':c['revision'],'files':actual}
dump(ASSETS/'operator.json',operator)
for key in operator['order']:
 out=ASSETS/f'{key}-run-v1';started=time.monotonic()
 print('Starting locked real CPU model run',key,datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
 command=['.venv/bin/python','tools/grounded_models.py','run','--model',key,'--freeze',str(freeze),'--out',str(out)]
 with (ASSETS/f'{key}-run-operator.log').open('w') as log:
  result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 operator['runs'][key]={'command':command,'returncode':result.returncode,'elapsed_seconds':time.monotonic()-started}
 dump(ASSETS/'operator.json',operator)
 print('Run returned',key,result.returncode,flush=True)
 command=['.venv/bin/python','tools/grounded_models.py','verify','--freeze',str(freeze),'--run',str(out),'--out',str(ASSETS/f'{key}-metrics.json')]
 with (ASSETS/f'{key}-verify.log').open('w') as log:
  verified=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 operator['runs'][key]['verification_returncode']=verified.returncode
 dump(ASSETS/'operator.json',operator)
 print('Model-free verification returned',key,verified.returncode,flush=True)
operator['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();dump(ASSETS/'operator.json',operator)
