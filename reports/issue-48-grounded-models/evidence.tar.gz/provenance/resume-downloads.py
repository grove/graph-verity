import concurrent.futures, hashlib, json, os, time, urllib.request
from pathlib import Path
cfg=json.loads(Path('configs/grounded-models-v1.json').read_text())
started=time.monotonic()
jobs=[];outputs={}
for key,c in cfg['candidates'].items():
 for name,f in c['files'].items():
  if not name.endswith('.safetensors'):continue
  path=Path('artifacts/issue-48/upstream')/key/name
  if path.exists():
   with path.open('rb') as stream: assert hashlib.file_digest(stream,'sha256').hexdigest()==f['sha256']
   continue
  part=path.with_suffix('.partial'); offset=part.stat().st_size if part.exists() else 0
  assert offset<f['bytes'];fd=os.open(part,os.O_CREAT|os.O_RDWR,0o644)
  outputs[path]=(part,fd,f)
  for a in range(offset,f['bytes'],256*1024*1024):
   b=min(a+256*1024*1024,f['bytes'])-1
   jobs.append((key,c,name,fd,a,b,f['bytes']))
def transfer(job):
 key,c,name,fd,a,b,total=job
 url=f"https://huggingface.co/{c['repo']}/resolve/{c['revision']}/{name}?download=true&segment={a}"
 req=urllib.request.Request(url,headers={'Range':f'bytes={a}-{b}'})
 with urllib.request.urlopen(req,timeout=120) as response:
  assert response.status==206 and response.headers['Content-Range']==f'bytes {a}-{b}/{total}',(key,a,response.headers.get('Content-Range'))
  offset=a
  while block:=response.read(4*1024*1024):
   assert offset+len(block)<=b+1
   assert os.pwrite(fd,block,offset)==len(block)
   offset+=len(block)
  assert offset==b+1,(key,a,offset,b)
 print(key,name,a,b,'complete',round(time.monotonic()-started,1),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:list(pool.map(transfer,jobs))
for path,(part,fd,f) in outputs.items():
 os.fsync(fd);os.close(fd)
 with part.open('rb') as stream: actual=hashlib.file_digest(stream,'sha256').hexdigest()
 assert actual==f['sha256'] and part.stat().st_size==f['bytes'],(path,actual)
 part.rename(path); print('VERIFIED',path,f['bytes'],actual,flush=True)
