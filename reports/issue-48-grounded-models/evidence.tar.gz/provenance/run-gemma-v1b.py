from pathlib import Path
import datetime,json,subprocess,time
p=Path('artifacts/issue-48');freeze=p/'locked-gemma-v1b';out=p/'gemma4-run-v1b'
op={'variant':'issue48-v1b-native-bos-stream','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'prior_gemma_attempt':'gemma4-run-v1; stopped before any generation; retained unchanged',
    'qwen_rerun':False,'task_and_numeric_settings_unchanged':True,'all_model_facing_packets_identical':True}
(p/'gemma4-v1b-operator.json').write_text(json.dumps(op,indent=2)+'\n')
started=time.monotonic()
command=['.venv/bin/python','tools/grounded_models.py','run','--model','gemma4','--freeze',str(freeze),'--out',str(out)]
with (p/'gemma4-v1b-run-operator.log').open('x') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
op.update(command=command,returncode=result.returncode,elapsed_seconds=time.monotonic()-started,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(p/'gemma4-v1b-operator.json').write_text(json.dumps(op,indent=2)+'\n')
command=['.venv/bin/python','tools/grounded_models.py','verify','--freeze',str(freeze),'--run',str(out),'--out',str(p/'gemma4-v1b-metrics.json')]
with (p/'gemma4-v1b-verify.log').open('x') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
op['verification_returncode']=r.returncode;(p/'gemma4-v1b-operator.json').write_text(json.dumps(op,indent=2)+'\n')
print(json.dumps(op,indent=2),flush=True)
