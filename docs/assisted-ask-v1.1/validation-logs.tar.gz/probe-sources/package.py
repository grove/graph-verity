"""Publish fresh, credential-free baseline receipts after the full pipeline passes."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

root = Path('/Users/grove/projects/graph-verity')
out = root / 'docs/assisted-ask-v1.1'
pipeline_dir = Path('/private/tmp/graph-verity-language-verify/artifacts/pre-llm')
pipeline = json.loads((pipeline_dir / 'verification.json').read_bytes())
assert pipeline['status'] == 'passed', pipeline['status']
assert len(pipeline['commands']) == 41
assert pipeline['git_commit'] == '294fcf0589b02dca1ff497b3cfe37689551e4986'
assert all((c['returncode'] == 0) == c['expected_success'] for c in pipeline['commands'])
task = Path(Path('/private/tmp/graph-verity-language-task-path').read_text())
files = {}
for p in sorted(Path('/private/tmp').glob('graph-verity-language-*.log')):
    files[p.name] = p.read_bytes()
for p in sorted(pipeline_dir.iterdir()):
    if p.is_file() and p.name.endswith(('.stdout.txt', '.stderr.txt', '.json', '.md')) and p.name != 'rebuilt.nq':
        files['pipeline/' + p.name] = p.read_bytes()
for name in ['probe.py', 'preservation.py', 'baseline-browser.mjs', 'browser-runner.py', 'package.py']:
    p = Path('/private/tmp/graph-verity-language-' + name)
    files['probe-sources/' + name] = p.read_bytes()
files['task-baseline.json'] = (task / 'baseline.json').read_bytes()
for name, body in files.items():
    assert not re.search(rb'Bearer [A-Za-z0-9_-]{20,}|https?://127\.0\.0\.1:[0-9]+/#[a-f0-9]{32,}', body), name
sha = lambda raw: hashlib.sha256(raw).hexdigest()
with (out / 'validation-logs.tar.gz').open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, body in sorted(files.items()):
                info = tarfile.TarInfo(name)
                info.size = len(body)
                info.mode = 0o644
                info.mtime = 0
                archive.addfile(info, io.BytesIO(body))
index = dict(archive_sha256=sha((out / 'validation-logs.tar.gz').read_bytes()),
             redaction=False, entries={n:dict(sha256=sha(b), bytes=len(b)) for n,b in sorted(files.items())})
(out / 'validation-log-files.json').write_text(json.dumps(index, indent=2) + '\n')
observations = Path('/private/tmp/graph-verity-language-observations.json').read_bytes()
assert all(('"' + k + '"').encode() not in observations for k in ['token','credential','Authorization','tab'])
(out / 'observations.json').write_bytes(observations)
counts = []
for shard in (0,1):
    text = (pipeline_dir / f'reporting-tests-{shard}.stderr.txt').read_text()
    counts.append(int(re.search(r'Ran (\d+) tests', text).group(1)))
    assert text.rstrip().endswith('OK')
rust = (pipeline_dir / 'rust-tests.stdout.txt').read_text()
rust_count = sum(map(int,re.findall(r'test result: ok\. (\d+) passed',rust)))
assert rust_count == 100
source_names = ['tools/assisted_ask.py','tools/test_assisted_ask.py','tools/assisted_ask_browser.mjs',
                'tools/assisted_ask_ui_v1/app.js','tools/assisted_ask_ui_v1/index.html','tools/assisted_ask_ui_v1/style.css',
                'tools/local_find.py','tools/local_nl_ask.py','tools/verify_pre_llm.py']
receipt = dict(captured_at=datetime.now(timezone.utc).isoformat(),decision='INCONCLUSIVE_REVISE',
    implementation_status='blocked_proposal_only',language_filter_implemented=False,
    rust_contract_extension_required=True,rust_contract_extension_implemented=False,
    blocker='Current root source-hash invariants pin the Rust extension points; no safe small additive public execution path.',
    pipeline=pipeline,current_python_tests=counts,current_python_skips=0,rust_tests=rust_count,
    focused_python_passed=10,focused_rust_passed=17,focused_browser_sessions_passed=8,
    additional_exact_rdf_dom_browser_sessions_passed=1,additional_http_rust_journeys=4,
    language_filtered_journeys_executed=0,
    retained_failure='focused-1: Cargo test briefly replaced the disposable server binary during a concurrent build; focused-2 passed unchanged after builds completed.',
    deadlines=dict(pipeline_per_command_seconds=600,browser_subprocess_seconds=120,
                   browser_startup_seconds=15,browser_ui_wait_seconds=20,rust_child_seconds=45,
                   focused_shell_outer_deadline_seconds=None,deadlines_increased=False),
    tested_current_sources_sha256={n:sha((root/n).read_bytes()) for n in source_names},
    product_sources_changed=False,inference_performed=False,physical_model_weights_rehashed=False,
    sealed_holdouts_accessed=False,history_resealed=False,human_comprehension='unmeasured; zero independent observations')
(out / 'validation.json').write_text(json.dumps(receipt, indent=2) + '\n')
p = out / 'validation.md'
text = p.read_text()
needle='All task-baseline tracked files and the original registered binary are compared'
assert text.count(needle)==1
paragraph=(f'**41/41 pipeline command checks passed** on the unchanged product baseline: '
           f'**{counts[0]} + {counts[1]} current Python tests**, zero skips, all required '
           f'browsers, **{rust_count} Rust tests**, formatting/Clippy, original historical '
           'replays, source/scope canaries, byte rebuild, schema/catalog parity, '
           '38 Wikidata and 35 transfer-development executable oracles, and '
           'manual/fixture approval/evidence checks. The locked-holdout sentinel '
           'was rejected before access. No full-pipeline failure or deadline increase. '
           'The PR adds documentation/receipts only; these results do not imply '
           'that v1.1 is implemented.\n\n')
p.write_text(text.replace(needle,paragraph+needle))
checks={str(p.relative_to(out)):sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='checksums.json'}
checks['../assisted-ask-v1.1-proposal.md']=sha((out.parent/'assisted-ask-v1.1-proposal.md').read_bytes())
(out/'checksums.json').write_text(json.dumps(checks,indent=2)+'\n')
print('PASS: packaged',len(files),'log/source members;',counts,'Python tests;',rust_count,'Rust tests; 41 pipeline checks')
