"""Run exact RDF/DOM baseline assertions with the real unchanged application."""
from pathlib import Path
import shutil
import subprocess
import sys
import threading

sys.path.insert(0, '/Users/grove/projects/graph-verity/tools')
import assisted_ask as ask

chrome = shutil.which('chromium') or shutil.which('google-chrome')
if not chrome:
    chrome = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
assert Path(chrome).is_file()
bundle = ask.Bundle(Path('/private/tmp/graph-verity-language-demo-verity'),
                    ask.DATA / 'snapshot.nq', 'nquads', ask.DATA / 'policy.json',
                    ask.DATA / 'scope.json', ask.DATA / 'discovery.json')
server = ask.Server(bundle)
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()
try:
    subprocess.run(['node', '/private/tmp/graph-verity-language-baseline-browser.mjs',
                    chrome, server.url, 'baseline-values'], check=True, timeout=120)
finally:
    server.shutdown()
    server.server_close()
    thread.join()
    bundle.close()
