"""Compare original task/historical/native inventories without touching model assets."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import stat
import tarfile

root = Path('/Users/grove/projects/graph-verity')
task = Path(Path('/private/tmp/graph-verity-language-task-path').read_text())
baseline = json.loads((task / 'baseline.json').read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
changed = []
for name, row in baseline['files'].items():
    p = root / name
    if not p.is_file() or sha(p) != row['sha256'] or p.stat().st_mtime_ns != row['mtime_ns'] or p.stat().st_mode != row['mode']:
        changed.append(name)
assert changed == [], changed
binary = root / 'target/debug/verity'
assert sha(binary) == baseline['binary']['sha256']
assert binary.stat().st_mtime_ns == baseline['binary']['mtime_ns']
old = json.loads((root / 'experiments/ask-alpha-observable-r2-native-evidence/baseline.json').read_bytes())['files']
missing = [n for n in old if not (root / n).is_file()]
historical_changes = [n for n,r in old.items() if (root / n).is_file() and sha(root / n) != r['sha256']]
assert missing == []
assert historical_changes == ['README.md'], historical_changes
inventory = json.loads((root / 'experiments/ask-alpha-observable-r2-native-evidence/raw-files.json').read_bytes())['files']
native = root / 'artifacts/ask-alpha-preview-v1-observable-r2'
assert {str(p.relative_to(native)) for p in native.rglob('*') if p.is_file() and not p.is_relative_to(native/'freeze')} == set(inventory)
for name,row in inventory.items():
    p = native / name
    assert (sha(p), p.stat().st_size, p.stat().st_mtime_ns, oct(stat.S_IMODE(p.stat().st_mode))) == (
        row['sha256'],row['bytes'],row['mtime_ns'],row['mode']), name
with tarfile.open(root / 'docs/ask-alpha-preview-v1-observable-r2/freeze.tar.gz') as archive:
    frozen = {m.name: archive.extractfile(m).read() for m in archive if m.isfile()}
assert {str(p.relative_to(native/'freeze')):p.read_bytes() for p in (native/'freeze').rglob('*') if p.is_file()} == frozen
pins = json.loads(frozen['freeze.json'])['inputs']
assert all(sha(root/n) == h for n,h in pins.items())
receipt = dict(captured_at=datetime.now(timezone.utc).isoformat(),
    base_commit='294fcf0589b02dca1ff497b3cfe37689551e4986',
    task_baseline_tracked_files=len(baseline['files']),
    task_baseline_content_mtime_mode_changes=changed,
    historical_baseline_files=len(old), historical_missing=missing,
    historical_content_changes_since_original_baseline=historical_changes,
    historical_note='README.md already differed before this task; all task-baseline files remain byte/mtime/mode identical.',
    frozen_current_input_hashes=len(pins), frozen_current_input_mismatches=[],
    frozen_rust_cargo_paths=len([n for n in pins if n.startswith(('crates/','Cargo'))]),
    native_files=len(inventory), native_bytes_membership_mtime_modes_unchanged=True,
    native_freeze_members=len(frozen), native_freeze_bytes_membership_unchanged=True,
    registered_binary=baseline['binary'], registered_binary_unchanged=True,
    registered_model_runtime_identity_receipts='Verified by unchanged original checker and original raw-evidence hashes; physical weights not rehashed.',
    inference_performed=False, model_weights_accessed=False, sealed_holdouts_accessed=False,
    history_resealed=False, production_code_changed=False)
destination = root / 'docs/assisted-ask-v1.1/preservation.json'
destination.write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS: task baseline, historical baseline, current source pins, original native evidence/freeze and registered binary preserved')
