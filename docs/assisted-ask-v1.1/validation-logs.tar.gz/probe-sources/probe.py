"""Read-only baseline/contract probes; no inference or historical source changes."""
import copy
import http.client
import json
from pathlib import Path
import subprocess
import sys
import threading

sys.path.insert(0, '/Users/grove/projects/graph-verity/tools')
import assisted_ask as ask

bundle = ask.Bundle(Path('/private/tmp/graph-verity-language-demo-verity'),
                    ask.DATA / 'snapshot.nq', 'nquads', ask.DATA / 'policy.json',
                    ask.DATA / 'scope.json', ask.DATA / 'discovery.json')
expected = {
    'en': 'University of Tromsø – The Arctic University of Norway',
    'nb': 'Universitetet i Tromsø – Norges arktiske universitet',
    'nn': 'Universitetet i Tromsø – Noregs arktiske universitet',
}
observed = {'base_commit': '294fcf0589b02dca1ff497b3cfe37689551e4986',
            'inference_performed': False, 'journeys': [], 'contract_probes': []}
server = ask.Server(bundle)
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()
tab = ''

def post(route, body):
    global tab
    conn = http.client.HTTPConnection(server.authority, timeout=50)
    conn.request('POST', route, json.dumps(body), {
        'Origin': server.origin, 'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + server.credential, 'X-Verity-Tab': tab})
    response = conn.getresponse()
    status, data = response.status, json.loads(response.read())
    conn.close()
    if route == '/api/session' and status == 200:
        tab = data['tab']
    return status, data

try:
    assert post('/api/session', {})[0] == 200
    for ui_language in ('en', 'nb'):
        for code in ('P856', 'P1448'):
            selection = dict(entity=ask.ENTITY, predicate=ask.PREDICATES[code],
                             language=ui_language, question='only English names')
            status, review = post(ask.PREFIX + 'preview', selection)
            assert status == 200
            preview = review['resolved']['preview']
            assert preview['plan']['filters'] == []
            assert preview['plan']['scope'] == [ask.GRAPH]
            assert preview['plan']['snapshot_id'] == ask.SNAPSHOT
            status, receipt = post(ask.PREFIX + 'confirm',
                                   dict(token=review['token'], decision='approve'))
            assert status == 200
            result = receipt['outcome']['result']
            values = [a['value'] for a in receipt['answers']]
            if code == 'P1448':
                assert {v['language']: v['value'] for v in values} == expected
                assert all(v['datatype'] == 'http://www.w3.org/1999/02/22-rdf-syntax-ns#langString' for v in values)
            else:
                assert {v['value'] for v in values} == {'https://uit.no', 'https://en.uit.no/startsida'}
            assert result['complete_within_scope']
            assert result['evidence_complete_for_returned_rows']
            assert all(a['source_triples'] for a in receipt['answers'])
            assert receipt['provenance']['original_question_status'] == 'unverified_user_intent_not_interpreted'
            assert post(ask.PREFIX + 'confirm', dict(token=review['token'], decision='approve'))[0] == 400
            observed['journeys'].append(dict(ui_language=ui_language, predicate=code,
                                            preview=preview, receipt=receipt))
    base = bundle.assemble(ask.ENTITY, ask.PREDICATES['P1448'])
    for label, edit in [
        ('language_only_filter', {'template': {**base['template'], 'filter': {'language': 'en'}}}),
        ('unimplemented_ask_v2', {'version': 2}),
    ]:
        request = {**base, **edit}
        try:
            bundle.ask(request)
        except subprocess.CalledProcessError:
            observed['contract_probes'].append(dict(probe=label, rust_rejected=True))
        else:
            raise AssertionError(label + ' unexpectedly accepted')
    typed = copy.deepcopy(base)
    typed['template']['filter'] = dict(op='eq', value=dict(
        lexical=expected['en'], datatype='http://www.w3.org/1999/02/22-rdf-syntax-ns#langString', language='en'))
    p = bundle.ask(typed)
    _, outcome = bundle.ask(typed, p['approval_id'])
    assert [v['step1']['value'] for v in outcome['result']['bindings']] == [expected['en']]
    typed['template']['filter']['value']['lexical'] = ''
    p = bundle.ask(typed)
    _, outcome = bundle.ask(typed, p['approval_id'])
    assert outcome['result']['bindings'] == []
    observed['contract_probes'].append(dict(probe='empty_lexical_en_equality_is_not_language_only',
                                           rows=0, en_names_present=1, rust_preview=p))
    Path('/private/tmp/graph-verity-language-observations.json').write_text(
        json.dumps(observed, ensure_ascii=False, indent=2) + '\n')
    print('PASS: four bilingual HTTP/Rust journeys, original RDF/evidence, replay rejection; Rust rejects language-only/v2 and treats tagged equality as lexical equality')
finally:
    server.shutdown()
    server.server_close()
    thread.join()
    bundle.close()
