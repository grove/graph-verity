# Pre-LLM verification

Commit: `ed12d0d0a1b05b9e6263b02d4ee3c35ac6bda913`

Executable oracle checks: **38 / 38**.

Recorded abstention cases: **8**; not model-tested and excluded from executable accuracy.

Formatting, Clippy, Rust tests, source hashes, byte-rebuild, independent gold, schema parity, deterministic catalog, manual/fixture evidence, and rejection demos passed.

No language model was run. Gold is machine-authored and human-review pending. No independent locked holdout or target-device parser measurement has been completed. This is engineering readiness for a local parser experiment, not a Phase 0 go decision.
