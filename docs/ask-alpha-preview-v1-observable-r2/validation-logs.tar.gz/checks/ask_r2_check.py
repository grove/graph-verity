import json, os, subprocess, sys, time
from datetime import datetime, timezone
from pathlib import Path
work=Path('artifacts/ask-alpha-observable-r2-work')
label=sys.argv[1]; deadline=int(sys.argv[2]); args=sys.argv[3:]
started=time.monotonic(); stamp=datetime.now(timezone.utc).isoformat()
with (work/(label+'.stdout')).open('xb') as out, (work/(label+'.stderr')).open('xb') as err:
    try:
        result=subprocess.run(args, stdout=out, stderr=err, timeout=deadline)
        code=result.returncode; timed_out=False
    except subprocess.TimeoutExpired:
        code=None; timed_out=True
receipt=dict(label=label, command=args, started_at=stamp, timeout_seconds=deadline, elapsed_seconds=time.monotonic()-started, returncode=code, timed_out=timed_out)
with (work/'attempts.jsonl').open('a') as stream:
    stream.write(json.dumps(receipt)+'\n')
print(json.dumps(receipt))
sys.exit(code if code is not None else 124)
