import sys
from pathlib import Path
sys.path.insert(0,'tools')
import ask_alpha_trial_observable_r2 as t
work=t.ROOT/'artifacts/ask-alpha-observable-r2-work/preload'
work.mkdir()
f=t.verify()
python=f['runtime_identity']['candidates']['qwen35']['preparation_receipt']['commands'][2][0]
with t.n.native_config(f['runtime_config']):
    code=t.a.bounded([python,t.ROOT/'tools/native_one_hop_v1h_tokens.py',t.FREEZE/'token-job.json',work/'token-counts.json'],work,'tokenizer',120)
    t.require(code==0,'Tokenizer failed')
    t.require(t.b.read(work/'token-counts.json')==t.b.read(t.FREEZE/'token-counts.json'),'Tokenizer recount mismatch')
    t.a.grammar_controls(t.b.read(t.FREEZE/'contexts/alpha-01.json'),work/'grammar-controls')
t.b.write(work/'result.json',dict(token_arrays_counts_prompts_exact=True,native_grammar_controls='passed',model_loaded=False,inference_performed=False,executions=0,tokenizer_timeout_seconds=120))
