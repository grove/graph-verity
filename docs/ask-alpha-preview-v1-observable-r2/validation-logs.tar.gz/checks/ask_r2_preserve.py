import hashlib, json, subprocess, sys
from pathlib import Path
sys.path.insert(0,'tools')
import ask_alpha_trial as old
root=Path.cwd(); work=root/'artifacts/ask-alpha-observable-r2-work'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
tracked=subprocess.check_output(['git','ls-tree','-r','--name-only','e2f22ce8988b18939ee05dbfadbd9e15447cc82f'],text=True).splitlines()
paths={root/p for p in tracked}
paths.update(p for p in (root/'artifacts').rglob('*attempt*.json') if p.is_file())
paths.update(p for p in (root/'artifacts/ask-alpha-v1').rglob('*') if p.is_file())
paths.add(root/'target/debug/verity')
asset_root=old.a.g.ASSETS
assets={str(p.relative_to(root)):dict(size=p.stat().st_size, mtime_ns=p.stat().st_mtime_ns) for p in asset_root.rglob('*') if p.is_file()}
value=dict(baseline='e2f22ce8988b18939ee05dbfadbd9e15447cc82f', file_sha256={str(p.relative_to(root)):digest(p) for p in sorted(paths)}, asset_root=str(asset_root.relative_to(root)), asset_metadata=assets)
if sys.argv[1]=='before':
    with (work/'preservation-before.json').open('x') as f: json.dump(value,f,indent=2)
else:
    before=json.loads((work/'preservation-before.json').read_text())
    changed=[p for p,h in before['file_sha256'].items() if not (root/p).exists() or digest(root/p)!=h]
    assert not changed, changed
    assert before['asset_metadata']==assets,'Asset file membership/metadata changed'
    with (work/'preservation-after.json').open('x') as f: json.dump(dict(unchanged_files=len(before['file_sha256']), original_files_sha256=before['file_sha256'], model_asset_metadata_unchanged=True, model_asset_files=len(assets), decision='INCONCLUSIVE_REVISE'),f,indent=2)
print(json.dumps(dict(files=len(paths),asset_files=len(assets),original_registration_sha256=digest(old.REG),original_archive_sha256=digest(old.ARCHIVE),ledger_sha256=digest(old.LEDGER))))
