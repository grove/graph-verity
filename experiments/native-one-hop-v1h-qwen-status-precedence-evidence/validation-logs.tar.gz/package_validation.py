"""Retain complete model-free validation logs, including the analyzer self-check."""
import gzip
import hashlib
import io
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import tempfile

root = Path.cwd()
base = root / 'artifacts/issue83-qwen-status-precedence-execution'
report = root / 'experiments/native-one-hop-v1h-qwen-status-precedence-evidence'
read = lambda p: json.loads(p.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
pipeline = read(base / 'full-pipeline-validation.json')
assert pipeline['status'] == 'passed' and pipeline['registered_binary_unchanged']
checks = read(base / 'verification-checkout/artifacts/pre-llm/verification.json')
assert checks['status'] == 'passed'
assert all((c['returncode'] == 0) == c['expected_success'] for c in checks['commands'])
with (base/'analysis-self-check.stdout.txt').open('w') as out, (base/'analysis-self-check.stderr.txt').open('w') as err:
    subprocess.run([sys.executable, str(report/'analyze.py'), '--check'], stdout=out, stderr=err, check=True)
spec = importlib.util.spec_from_file_location('blocked_evidence_analysis', report/'analyze.py')
analyzer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(analyzer)
with tempfile.TemporaryDirectory(prefix='blocked-evidence-tamper-') as temp:
    analyzer.REPORT = Path(temp)
    for name in ['evidence-files.json', 'evidence.tar.gz']:
        (analyzer.REPORT/name).write_bytes((report/name).read_bytes())
    with (analyzer.REPORT/'evidence.tar.gz').open('ab') as stream:
        stream.write(b'changed')
    try:
        analyzer.analyze()
    except AssertionError:
        (base/'analysis-integrity-test.json').write_text(json.dumps(dict(tampered_archive_rejected=True))+'\n')
    else:
        raise AssertionError('Analyzer accepted altered evidence')
original = read(base / 'original-tracked-files.json')
assert all(sha((root / name).read_bytes()) == digest for name, digest in original.items())
reg = read(root / 'experiments/native-one-hop-v1h-qwen-status-precedence/registration.json')
ledger = root / 'artifacts' / ('v1h-budget-attempts-' + reg['freeze_sha256'] + '.json')
assert not ledger.exists() and not (root/'artifacts/issue83-v1h-qwen-status-precedence-first').exists()
logs = {}
for path in (base/'verification-checkout/artifacts/pre-llm').rglob('*'):
    if path.is_file() and path.suffix in ['.json', '.txt']:
        logs['pre-llm/' + str(path.relative_to(base/'verification-checkout/artifacts/pre-llm'))] = path.read_bytes()
for name in ['full-pipeline-validation.json', 'isolated-build.stdout.txt', 'isolated-build.stderr.txt',
             'complete-pipeline.stdout.txt', 'complete-pipeline.stderr.txt', 'analysis-self-check.stdout.txt',
             'analysis-self-check.stderr.txt', 'baseline-original-byte-replay.json', 'issue83-state.json',
             'analysis-integrity-test.json', 'package_validation.py']:
    logs[name] = (base/name).read_bytes()
archive = report/'validation-logs.tar.gz'
assert not archive.exists()
with archive.open('xb') as stream, gzip.GzipFile(fileobj=stream,filename='',mode='wb',mtime=0) as compressed, tarfile.open(fileobj=compressed,mode='w') as bundle:
    for name, raw in sorted(logs.items()):
        info=tarfile.TarInfo(name);info.size=len(raw)
        bundle.addfile(info,io.BytesIO(raw))
dump = lambda p, value: p.write_text(json.dumps(value,indent=2)+'\n')
dump(report/'validation-logs-files.json',dict(archive_sha256=sha(archive.read_bytes()),files={n:sha(b) for n,b in sorted(logs.items())}))
dump(report/'verification.json',checks)
stderr = (base/'verification-checkout/artifacts/pre-llm/reporting-tests.stderr.txt').read_text()
rust = (base/'verification-checkout/artifacts/pre-llm/rust-tests.stdout.txt').read_text()
validation=dict(status='passed', full_pipeline=pipeline, full_pipeline_checks=len(checks['commands']),
    python_test_counts=[int(n) for n in re.findall(r'Ran (\d+) tests?',stderr)],
    python_tests_skipped=bool(re.search(r'OK \(skipped=|\.\.\. skipped ',stderr)),
    rust_tests_passed=sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed',rust)),
    native_grammar_controls_passed=12, native_sampling_controls_attempted=0,
    baseline_original_byte_rust_previews_replayed=74, new_model_output_rust_previews=0,
    independent_tokenizer_recount_exact=True, analyzer_exact_reproduction_passed=True,
    tampered_archive_rejection_passed=True, original_tracked_files_unchanged=len(original),
    inference_command_issued=False, model_loaded=False, generation_attempts=0,retries=0,
    model_generated_rdf_executions=0, independent_human_review='pending',
    scope='Full existing pipeline at exact authorized PR commit; evidence analyzer separately self-checked. Only new evidence/report files added afterward.')
assert not validation['python_tests_skipped']
dump(report/'validation.json',validation)
print(json.dumps({k:v for k,v in validation.items() if k!='full_pipeline'},indent=2))
