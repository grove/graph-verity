# Owner authorization received in this session

Repository: `grove/graph-verity`; PR #97; exact PR commit:
`e540f90e7624ef63cc031128a0704b1222450082`.

The owner explicitly supplied: **"PR #97 passed. I authorize it."**

The owner authorized one Qwen3.5-9B Q4_K_M experiment, two native sampling
controls and 36 semantic observations, maximum 38 completion requests, zero
retries, original 1024 MiB swap admission, offline operator-only execution,
Rust preview only and zero model-generated RDF executions.

Exact authorized command:

```bash
.venv/bin/python tools/native_one_hop_v1h_status_precedence.py run \
  --freeze artifacts/v1h-qwen-status-precedence \
  --model qwen35 \
  --allow-inference \
  --out artifacts/issue83-v1h-qwen-status-precedence-first
```

The owner required verification of the exact PR commit and successful GitHub CI,
registered sources unchanged, restoration of the committed freeze into a fresh
directory, registration/hash/asset/Rust/token verification, output and no-retry
ledger inspection, and all original integrity/resource gates including a fresh
host preflight within 60 seconds of loading. If any gate fails, record the
blocker and stop without inference. No further authorization is required for
the exact command if every registered gate passes.

No Gemma, v1g, extra experiment, model download, threshold adjustment or #75
integration is authorized. Preserve original bytes, streams, prompts, token IDs,
parity, controls, previews, validation, timing/resources, integrity, authorization
and stop reasons. Compare unchanged Qwen v1h baseline: unsupported 2/6 oracle
and 4/6 BM25-v1; preserve 3/3 genuine clarification per condition; report supported
candidate regressions, reverse failures and five plan fields, and independently
report rationale/source contradictions. Missing outcomes must be null.

After execution or a documented blocker, the owner explicitly authorized
reproducible model-free analysis, full applicable model-free validation,
historical preservation verification and a separate evidence PR, stacked if
#97 remains unmerged. Neither PR may be merged. Independent human review remains
pending. Stop after the evidence PR, with no retry or follow-up inference.

Decision: `INCONCLUSIVE_REVISE`. Issue #83 stays OPEN; #75 integration DISABLED.
Completion does not establish semantic correctness, superiority or readiness.
