"""Operator receipts only; do not load weights or submit completions."""
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path.cwd() / 'tools'))
import native_one_hop_v1h_status_precedence as s

out = Path(__file__).resolve().parent
folder = s.ROOT / 'artifacts/v1h-qwen-status-precedence'
state = dict(status='checking', model_loaded=False, generation_attempts=0, retries=0)
try:
    pr = s.h.read(out / 'pr97-verification.json')
    assert pr['headRefOid'] == 'e540f90e7624ef63cc031128a0704b1222450082'
    assert pr['statusCheckRollup'] and all(c['conclusion'] == 'SUCCESS' for c in pr['statusCheckRollup'])
    with s.experiment(), s.h.adapter():
        frozen = s.h.verify_registration(folder)
        assets = s.h.a.assets(out / 'assets.json')
        assert {k: assets[k] for k in frozen['runtime_identity']} == frozen['runtime_identity']
        measured = s.h.count_tokens(folder, out / 'token-recount', ['qwen35'], sections=True)
        saved = s.h.read(folder / 'tokenization/counts.json')
        assert measured == saved
        s.h.a.grammar_controls(s.h.read(folder / 'contexts/eva-01-oracle.json'), out / 'grammar-controls')
        host = s.h.a.preflight(out / 'host.json')
        state.update(status='blocked' if host['blockers'] else 'passed', blockers=host['blockers'])
except BaseException as error:
    state.update(status='blocked', error=type(error).__name__ + ': ' + str(error))
finally:
    s.h.dump(out / 'gate-results.json', state)
    print(json.dumps(state, indent=2))
raise SystemExit(0 if state['status'] == 'passed' else 1)
