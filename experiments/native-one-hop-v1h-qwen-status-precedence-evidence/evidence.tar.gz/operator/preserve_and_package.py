"""Package the failed admission gates; never invoke the inference runner."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
import analyze_v1h_qwen as baseline
import native_one_hop_v1h_status_precedence as s

operator = root / 'artifacts/issue83-qwen-status-precedence-execution'
report = root / 'experiments/native-one-hop-v1h-qwen-status-precedence-evidence'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
original = s.h.read(operator / 'original-tracked-files.json')
assert all(sha((root / name).read_bytes()) == digest for name, digest in original.items())
history = s.h.read(root / 'reports/issue-83-native-one-hop-v1f-diagnostic/historical-sha256.json')
assert all(sha((root / name).read_bytes()) == digest for name, digest in history.items())
parent = s.h.read(s.PARENT / 'registration.json')
assert all(sha((root / name).read_bytes()) == digest for name, digest in parent['freeze_manifest']['input_sha256'].items())
with s.experiment():
    frozen = s.h.verify_registration(root / 'artifacts/v1h-qwen-status-precedence')
prior = baseline.analyze()
assert prior == s.h.read(baseline.REPORT / 'analysis.json')
assert baseline.markdown(prior) == (baseline.REPORT / 'comparison.md').read_text()
assert baseline.failure_matrix(prior) == (baseline.REPORT / 'failure-matrix.md').read_text()
registration = s.h.read(s.RELEASE / 'registration.json')
ledger = root / 'artifacts' / ('v1h-budget-attempts-' + registration['freeze_sha256'] + '.json')
output = root / 'artifacts/issue83-v1h-qwen-status-precedence-first'
assert not ledger.exists() and not output.exists()
s.h.dump(operator / 'after-attempt.json', dict(ledger_path=str(ledger.relative_to(root)),
    ledger_exists=False, output_exists=False, inference_command_issued=False, generation_attempts=0))
s.h.dump(report / 'preservation.json', dict(status='passed', original_tracked_files_verified=len(original),
    historical_hashes_verified=len(history), parent_source_hashes_verified=len(parent['freeze_manifest']['input_sha256']),
    registered_source_hashes_verified=len(frozen['input_sha256']), all_original_tracked_bytes_unchanged=True,
    registered_binary_sha256=sha(s.h.a.BINARY.read_bytes()), baseline_analysis_reproduced_byte_for_byte=True,
    baseline_markdown_reports_reproduced_byte_for_byte=True, original_tracked_files_manifest_sha256=sha((operator/'original-tracked-files.json').read_bytes()),
    model_generated_rdf_executions=0))
payload = {'registration.json': (s.RELEASE / 'registration.json').read_bytes()}
for path in (root / 'artifacts/v1h-qwen-status-precedence').rglob('*'):
    if path.is_file(): payload['freeze/' + str(path.relative_to(root / 'artifacts/v1h-qwen-status-precedence'))] = path.read_bytes()
for name in frozen['input_sha256']:
    payload['source/' + name] = (root / name).read_bytes()
for path in operator.rglob('*'):
    rel = path.relative_to(operator)
    if 'verification-checkout' in rel.parts or rel.name.startswith(('complete-pipeline.', 'isolated-build.', 'full-pipeline-validation.')):
        continue
    if path.is_file(): payload['operator/' + str(rel)] = path.read_bytes()
archive = report / 'evidence.tar.gz'
assert not archive.exists()
with archive.open('xb') as stream, gzip.GzipFile(fileobj=stream, filename='', mode='wb', mtime=0) as compressed, tarfile.open(fileobj=compressed, mode='w') as bundle:
    for name, raw in sorted(payload.items()):
        member = tarfile.TarInfo(name)
        member.size = len(raw)
        bundle.addfile(member, io.BytesIO(raw))
s.h.dump(report / 'evidence-files.json', dict(archive_sha256=sha(archive.read_bytes()),
    files={name: sha(raw) for name, raw in sorted(payload.items())}))
print(json.dumps(s.h.read(report / 'preservation.json'), indent=2))
