"""Preserve the single run and immutable registrations; no inference."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
root=Path.cwd();sys.path.insert(0,str(root/'tools'))
import native_one_hop_v1h_direction as v
h=v.h
operator=root/'artifacts/issue83-direction-execution'
report=root/'experiments/native-one-hop-v1h-qwen-direction-only-first-evidence'
freeze=root/'artifacts/v1h-qwen-direction-only'
run=root/'artifacts/issue83-v1h-qwen-direction-only-first'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
base='cf08c28cb1c5396eaa703f5678c89a526e2b9884'
original={}
process=subprocess.Popen(['git','archive',base],stdout=subprocess.PIPE)
with tarfile.open(fileobj=process.stdout,mode='r|') as archive:
 for member in archive:
  if member.isfile():
   raw=archive.extractfile(member).read();digest=sha(raw)
   assert h.sha(root/member.name)==digest,member.name
   original[member.name]=digest
assert process.wait()==0
h.dump(operator/'original-tracked-files.json',original)
history=h.read(root/'reports/issue-83-native-one-hop-v1f-diagnostic/historical-sha256.json')
assert len(history)==801
for name,digest in history.items():assert h.sha(root/name)==digest,name
registrations=[]
for name in original:
 if not (name.startswith('experiments/') and name.endswith('/registration.json')):continue
 reg=h.read(root/name)
 if 'archive_sha256' in reg:
  archive=(root/name).parent/'freeze.tar.gz';assert h.sha(archive)==reg['archive_sha256'],name
  payload=h.a.g.archive_files(archive);frozen=json.loads(payload['freeze.json'])
  assert frozen==reg['freeze_manifest']
  assert {n:sha(b) for n,b in payload.items() if n!='checksums.json'}==json.loads(payload['checksums.json'])
  for source,digest in frozen['input_sha256'].items():
   assert sha(subprocess.check_output(['git','show',frozen['source_commit']+':'+source]))==digest,(name,source)
  registrations.append(dict(path=name,sha256=h.sha(root/name),archive_sha256=reg['archive_sha256'],source_hashes=len(frozen['input_sha256'])))
 elif 'input_sha256' in reg or 'source_input_sha256' in reg:
  hashes=reg.get('input_sha256',reg.get('source_input_sha256'))
  for source,digest in hashes.items():assert h.sha(root/source)==digest,(name,source)
  registrations.append(dict(path=name,sha256=h.sha(root/name),source_hashes=len(hashes)))
with v.experiment(): frozen=h.verify_registration(freeze)
state=h.read(run/'run.json');reg=h.read(v.RELEASE/'registration.json')
ledger=root/'artifacts'/('v1h-budget-attempts-'+reg['freeze_sha256']+'.json')
assert h.read(ledger)==['qwen35'];assert state['generation_attempts']<=38
h.dump(operator/'attempt-ledger.json',h.read(ledger))
h.dump(operator/'after-attempt.json',dict(ledger_path=str(ledger.relative_to(root)),ledger=h.read(ledger),output_exists=run.exists(),inference_command_issued_once=True,authorization_exhausted=True,further_inference_requires_new_explicit_authorization=True))
h.dump(report/'preservation.json',dict(status='passed',base_commit=base,original_tracked_files_verified=len(original),historical_hashes_verified=len(history),historical_registrations=registrations,registered_source_hashes_verified=len(frozen['input_sha256']),registered_binary_sha256=h.sha(h.a.BINARY),all_original_tracked_bytes_unchanged=True,model_generated_rdf_executions=0))
payload={'registration.json':(v.RELEASE/'registration.json').read_bytes(),'registered-freeze.tar.gz':(v.RELEASE/'freeze.tar.gz').read_bytes()}
for prefix,folder in [('freeze',freeze),('run',run)]:
 for path in folder.rglob('*'):
  if path.is_file():payload[prefix+'/'+str(path.relative_to(folder))]=path.read_bytes()
for name in frozen['input_sha256']:payload['source/'+name]=(root/name).read_bytes()
for name in ['tools/analyze_v1f.py','tools/analyze_v1f_r3.py','tools/analyze_v1h_qwen.py','experiments/native-one-hop-v1h-qwen-status-precedence-first-evidence/analyze.py',str((report/'analyze.py').relative_to(root)),str((report/'test_analysis.py').relative_to(root))]:
 payload['analysis-source/'+name]=(root/name).read_bytes()
for path in operator.rglob('*'):
 rel=path.relative_to(operator)
 if 'verification-checkout' in rel.parts or 'validation' in rel.parts:continue
 if path.is_file():payload['operator/'+str(rel)]=path.read_bytes()
archive=report/'evidence.tar.gz'
with archive.open('xb') as stream,gzip.GzipFile(fileobj=stream,filename='',mode='wb',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as bundle:
 for name,raw in sorted(payload.items()):
  member=tarfile.TarInfo(name);member.size=len(raw);bundle.addfile(member,io.BytesIO(raw))
h.dump(report/'evidence-files.json',dict(archive_sha256=h.sha(archive),files={n:sha(raw) for n,raw in sorted(payload.items())}))
print('Preserved',len(original),'original files,',len(history),'historical hashes;',len(payload),'evidence members')
