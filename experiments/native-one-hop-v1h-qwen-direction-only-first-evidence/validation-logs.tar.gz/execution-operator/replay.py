"""Original raw-byte Rust preview replay; never execute model plans."""
import json
from pathlib import Path
import sys
import tempfile
sys.path.insert(0,'tools')
import native_one_hop_v1h_direction as v
h=v.h;root=Path.cwd();out=root/'artifacts/issue83-direction-execution'
with v.experiment():
 current=h.replay(root/'artifacts/v1h-qwen-direction-only',root/'artifacts/issue83-v1h-qwen-direction-only-first')
archive=root/'experiments/native-one-hop-v1h-qwen-status-precedence-first-evidence/evidence.tar.gz'
payload=h.a.g.archive_files(archive)
saved=[name for name in payload if name.startswith('run/') and name.endswith('/rust.json')]
for member in saved:
 parent=member.removesuffix('/rust.json')
 with tempfile.TemporaryDirectory(prefix='direction-baseline-replay-') as temp:
  folder=Path(temp);raw=folder/'proposal.txt';raw.write_bytes(payload[parent+'/proposal.txt'])
  result=h.a.preview_raw(json.loads(payload[parent+'/context.json']),raw,folder,json.loads(payload[parent+'/catalog.json']))
  assert result==json.loads(payload[member]),member
h.dump(out/'original-byte-replay.json',dict(status='passed',current=current,baseline=dict(rust_previews=len(saved),archive_sha256=h.sha(archive)),registered_binary_sha256=h.sha(h.a.BINARY),inference_performed=False,model_generated_rdf_executions=0))
print(json.dumps(h.read(out/'original-byte-replay.json'),indent=2))
