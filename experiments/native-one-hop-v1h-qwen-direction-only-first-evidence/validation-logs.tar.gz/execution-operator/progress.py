import json
from pathlib import Path
root=Path('artifacts/issue83-v1h-qwen-direction-only-first')
if (root/'host.json').exists():
 h=json.loads((root/'host.json').read_text());print('host:',{k:h[k] for k in ['captured_at','swap_used_mib','blockers']})
rows=[json.loads(p.read_text()) for p in sorted(root.glob('diagnostic/*/*/observation.json'))]
print('Completed observations:',len(rows),'Requests created:',len(list(root.rglob('completion-request.json'))))
for r in rows: print(r['condition'],r['name'],r['status'],r.get('model_origin_status'),r.get('plan'))
if (root/'run.json').exists():
 r=json.loads((root/'run.json').read_text());print('FINAL:',{k:r.get(k) for k in ['status','error','generation_attempts','generation_completed','process_tree_rss']})
