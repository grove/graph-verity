"""Operator receipts only; never load weights or submit completions."""
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path.cwd() / 'tools'))
import native_one_hop_v1h_direction as v
out = Path(__file__).resolve().parent
folder = v.ROOT / 'artifacts/v1h-qwen-direction-only'
state = dict(status='checking', model_loaded=False, generation_attempts=0, retries=0)
try:
    pr = v.h.read(out / 'pr101-verification.json')
    assert pr['state'] == 'MERGED' and pr['mergeCommit']['oid'] == 'cf08c28cb1c5396eaa703f5678c89a526e2b9884'
    with v.experiment(), v.h.adapter():
        frozen = v.h.verify_registration(folder)
        state['registered_source_hashes_verified'] = len(frozen['input_sha256'])
        assets = v.h.a.assets(out / 'assets.json')
        assert {k: assets[k] for k in frozen['runtime_identity']} == frozen['runtime_identity']
        measured = v.h.count_tokens(folder, out / 'token-recount', ['qwen35'], sections=True)
        assert measured == v.h.read(folder / 'tokenization/counts.json')
        state['exact_prompt_token_recounts'] = len(measured['models']['qwen35']['rows'])
        v.h.a.grammar_controls(v.h.read(folder / 'contexts/eva-01-oracle.json'), out / 'grammar-controls')
        host = v.h.a.preflight(out / 'host.json')
        state.update(status='blocked' if host['blockers'] else 'passed', blockers=host['blockers'])
except BaseException as error:
    state.update(status='blocked', error=type(error).__name__ + ': ' + str(error))
finally:
    v.h.dump(out / 'gate-results.json', state)
    print(json.dumps(state, indent=2))
raise SystemExit(0 if state['status'] == 'passed' else 1)
