"""Retain the complete post-execution, model-free validation evidence."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

root = Path.cwd()
base = Path(__file__).resolve().parent
operator = root / 'artifacts/issue83-direction-execution'
report = root / 'experiments/native-one-hop-v1h-qwen-direction-only-first-evidence'
read = lambda p: json.loads(p.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
pipeline = read(base/'full-pipeline-validation.json')
checks = read(base/'verification-checkout/artifacts/pre-llm/verification.json')
assert pipeline['status'] == checks['status'] == 'passed' and pipeline['registered_binary_unchanged']
assert all((c['returncode']==0)==c['expected_success'] for c in checks['commands'])
for label,args in [('analysis-reproduction',[sys.executable,str(report/'analyze.py'),'--check']),
                   ('evidence-tests',[sys.executable,'-m','unittest','discover','-s',str(report),'-p','test_analysis.py','-v'])]:
    with (base/(label+'.stdout.txt')).open('w') as out,(base/(label+'.stderr.txt')).open('w') as err:
        subprocess.run(args,stdout=out,stderr=err,check=True)
original=read(operator/'original-tracked-files.json')
assert all(sha((root/n).read_bytes())==h for n,h in original.items())
analysis=read(report/'analysis.json')
logs={}
for path in (base/'verification-checkout/artifacts/pre-llm').rglob('*'):
    if path.is_file() and path.suffix in ['.json','.txt']:
        logs['pre-llm/'+str(path.relative_to(base/'verification-checkout/artifacts/pre-llm'))]=path.read_bytes()
for path in base.iterdir():
    if path.is_file(): logs['validation-operator/' + path.name] = path.read_bytes()
for path in operator.iterdir():
    if path.is_file(): logs['execution-operator/' + path.name] = path.read_bytes()
archive=report/'validation-logs.tar.gz';assert not archive.exists()
with archive.open('xb') as stream,gzip.GzipFile(fileobj=stream,filename='',mode='wb',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as bundle:
    for name,raw in sorted(logs.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);bundle.addfile(info,io.BytesIO(raw))
dump=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
dump(report/'validation-logs-files.json',dict(archive_sha256=sha(archive.read_bytes()),files={n:sha(b) for n,b in sorted(logs.items())}))
dump(report/'verification.json',checks)
stderr=(base/'verification-checkout/artifacts/pre-llm/reporting-tests.stderr.txt').read_text()
rust=(base/'verification-checkout/artifacts/pre-llm/rust-tests.stdout.txt').read_text()
validation=dict(status='passed',full_pipeline=pipeline,full_pipeline_checks=len(checks['commands']),
    python_test_counts=[int(n) for n in re.findall(r'Ran (\d+) tests?',stderr)],
    python_tests_skipped=bool(re.search(r'OK \(skipped=|\.\.\. skipped ',stderr)),
    rust_tests_passed=sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed',rust)),
    evidence_tests=3,analyzer_exact_reproduction_passed=True,tampered_archive_rejection_passed=True,resealed_false_review_excerpt_rejection_passed=True,
    required_browsers=True,all_original_tracked_bytes_unchanged=len(original),
    original_byte_rust_replay=read(operator/'original-byte-replay.json'),
    run_status=analysis['status'],generation_attempts=analysis['generation_attempts'],generation_completed=analysis['generation_completed'],
    further_inference_performed_by_validation=False,model_generated_rdf_executions=0,
    independent_human_review='pending',decision='INCONCLUSIVE_REVISE',
    authorization_exhausted=True,
    scope='Full unchanged applicable pipeline at the exact authorized source commit in isolated checkout after inference stopped; new evidence analyzer/tests separately validated.')
assert not validation['python_tests_skipped']
dump(report/'validation.json',validation)
print(json.dumps({k:v for k,v in validation.items() if k!='full_pipeline'},indent=2))
