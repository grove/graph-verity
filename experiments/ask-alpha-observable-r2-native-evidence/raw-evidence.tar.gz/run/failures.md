# Retained Ask draft evaluation

Origin: **retained_local_model**. INCONCLUSIVE_REVISE.
No model invoked; no draft executed. Human comprehension unmeasured.

## neighborhood_v2_definitions

```json
{
  "scheduled": 60,
  "completed_latency": {
    "samples": 60,
    "p50_ms": 29647.50047950656,
    "p95_ms": 253462.50179200433,
    "p99_ms": 299123.2885000063
  },
  "outcomes": {
    "completed": 60
  },
  "five_field_scheduled": {
    "numerator": 20,
    "denominator": 29
  },
  "five_field_completed": {
    "numerator": 20,
    "denominator": 29
  },
  "fields": {
    "start": {
      "numerator": 26,
      "denominator": 29
    },
    "predicate": {
      "numerator": 25,
      "denominator": 29
    },
    "graph": {
      "numerator": 27,
      "denominator": 29
    },
    "direction": {
      "numerator": 20,
      "denominator": 29
    },
    "output": {
      "numerator": 27,
      "denominator": 29
    }
  },
  "clarification": {
    "numerator": 6,
    "denominator": 23
  },
  "unsupported": {
    "numerator": 6,
    "denominator": 8
  },
  "false_clarification": 1,
  "false_unsupported": 7,
  "wrong_but_executable": {
    "numerator": 9,
    "denominator": 40
  },
  "wrong_but_executable_scheduled": {
    "numerator": 9,
    "denominator": 60
  },
  "unresolved_candidates": 11,
  "unjustified_relationship_selections": 13,
  "retrieval": {
    "numerator": 28,
    "denominator": 29
  },
  "rust": {
    "accepted": 60
  },
  "source_evidence": {
    "numerator": 0,
    "denominator": 0
  }
}
```

| Case | Outcome | Problem |
|---|---|---|
| alpha-04 | completed | unexpected model status; guess on unresolved intent |
| alpha-05 | completed | unexpected model status; guess on unresolved intent |
| alpha-06 | completed | unexpected model status; guess on unresolved intent |
| alpha-07 | completed | fields: predicate, direction; WRONG BUT EXECUTABLE |
| alpha-08 | completed | fields: start, direction; WRONG BUT EXECUTABLE; missing numeric start |
| alpha-09 | completed | unexpected model status; guess on unresolved intent |
| alpha-10 | completed | unexpected model status; guess on unresolved intent |
| alpha-13 | completed | unexpected model status; guess on unresolved intent |
| alpha-14 | completed | unexpected model status; guess on unresolved intent |
| alpha-22 | completed | unexpected model status |
| alpha-23 | completed | unexpected model status |
| alpha-24 | completed | unexpected model status |
| alpha-36 | completed | fields: direction; WRONG BUT EXECUTABLE |
| alpha-38 | completed | fields: predicate, direction; WRONG BUT EXECUTABLE |
| alpha-39 | completed | fields: direction; WRONG BUT EXECUTABLE |
| alpha-40 | completed | unexpected model status |
| alpha-41 | completed | fields: direction; WRONG BUT EXECUTABLE |
| alpha-43 | completed | unexpected model status |
| alpha-44 | completed | fields: direction; WRONG BUT EXECUTABLE |
| alpha-49 | completed | unexpected model status; guess on unresolved intent |
| alpha-50 | completed | unexpected model status; guess on unresolved intent |
| alpha-51 | completed | unexpected model status |
| alpha-55 | completed | unexpected model status; WRONG BUT EXECUTABLE |
| alpha-56 | completed | unexpected model status; WRONG BUT EXECUTABLE |
| alpha-57 | completed | unexpected model status |
| alpha-58 | completed | unexpected model status |
| alpha-59 | completed | unexpected model status; guess on unresolved intent |
| alpha-60 | completed | unexpected model status; guess on unresolved intent |

Full row JSON retains raw drafts, resolved fields and exact Rust rejection text.
Unresolved dispositions are automation targets, not definitive semantic gold. Rationale claims require source audit.
Source-evidence agreement is snapshot-only; schema validity and Rust acceptance do not prove interpretation.
