"""Run requested model-free checks only after the single native invocation exits."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/Users/grove/projects/graph-verity')
WORK = Path(__file__).resolve().parent


def main():
    assert (WORK / 'invocation-result.json').is_file(), 'Native invocation must have exited'
    assert not (WORK / 'post-validation-attempts.json').exists(), 'Preserve earlier checks'
    shutil.copytree(ROOT / 'artifacts/pre-llm', WORK / 'pre-llm-before-post-checks')
    env = dict(os.environ, REQUIRE_FIND_BROWSER='1')
    env['PATH'] = str(WORK / 'bin') + os.pathsep + env['PATH']
    assets = """import sys
from pathlib import Path
sys.path.insert(0, 'tools')
import ask_alpha_trial_observable_r2 as t
with t.n.native_config(t.verify()['runtime_config']):
    evidence = t.a.assets(Path('artifacts/ask-alpha-observable-r2-fresh-execution-work/after-assets.json'))
    assert evidence == t.b.read(t.OUTPUT / 'assets.json'), 'Post-run asset identity drift'
print('PASS: all retained asset identities match the run receipt')
"""
    commands = [
        ('replay', ['.venv/bin/python', str(WORK / 'replay.py')], 300),
        ('focused', ['.venv/bin/python', '-m', 'unittest', 'discover', '-s', 'tools',
                     '-p', 'test_ask_alpha_observable_r2.py', '-v'], 120),
        ('after-assets', ['.venv/bin/python', '-c', assets], 300),
        ('pipeline', ['.venv/bin/python', 'tools/verify_pre_llm.py'], 2400),
    ]
    rows = []
    for label, args, timeout in commands:
        row = dict(label=label, command=args, started_at=datetime.now(timezone.utc).isoformat(),
                   timeout_seconds=timeout)
        started = time.monotonic()
        with (WORK / ('post-' + label + '.stdout')).open('xb') as out, \
             (WORK / ('post-' + label + '.stderr')).open('xb') as err:
            try:
                result = subprocess.run(args, cwd=ROOT, env=env, stdout=out, stderr=err, timeout=timeout)
                row.update(returncode=result.returncode, timed_out=False)
            except subprocess.TimeoutExpired:
                row.update(returncode=None, timed_out=True)
        row['elapsed_seconds'] = time.monotonic() - started
        rows.append(row)
        (WORK / 'post-validation-attempts.json').write_text(json.dumps(rows, indent=2) + '\n')
        print(json.dumps(row), flush=True)
    shutil.copytree(ROOT / 'artifacts/pre-llm', WORK / 'post-pipeline-files')


if __name__ == '__main__':
    main()
