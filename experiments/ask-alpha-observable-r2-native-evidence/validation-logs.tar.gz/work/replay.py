"""Replay retained proposal bytes through the registered Rust preview and scorer."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path('/Users/grove/projects/graph-verity')
sys.path.insert(0, str(ROOT / 'tools'))
import ask_alpha_trial_observable_r2 as t

WORK = Path(__file__).resolve().parent
OUT = WORK / 'replay-output'


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main():
    assert (WORK / 'invocation-result.json').is_file(), 'Wait for the single invocation to exit'
    assert not OUT.exists(), 'Preserve existing replay evidence'
    t.verify()
    OUT.mkdir()
    run = t.b.read(t.OUTPUT / 'run.json')
    original = t.b.read(t.OUTPUT / 'score.json')
    observations = {r['id']: r for r in run['rows']}
    packets = t.e.packets()
    rows = []
    adapter = t.b.bundle()
    try:
        for request in t.b.read(t.FREEZE / 'schedule.json'):
            if request['kind'] != 'semantic':
                continue
            key = request['id']
            proposal = t.OUTPUT / 'requests' / key / 'proposal.txt'
            if not proposal.exists():
                continue
            raw = proposal.read_bytes()
            result = t.e.rust_preview(adapter, packets[key]['selection'], raw.decode('utf-8'))
            completed = observations[key]['outcome'] == 'completed'
            rows.append(dict(id=key, completed=completed, bytes=len(raw),
                             raw_sha256=hashlib.sha256(raw).hexdigest(), preview=result,
                             matches_original_preview=result == observations[key].get('rust') if completed else None))
            write(OUT / 'replay.json', dict(rows=rows, registered_score_reproduced=None,
                                           inference_performed=False, executions=0))
    finally:
        adapter.close()
    reproduced = t.e.score(run)
    write(OUT / 'score.json', reproduced)
    same = reproduced == original
    write(OUT / 'replay.json', dict(rows=rows, registered_score_reproduced=same,
                                   scorer_sha256=t.b.sha(ROOT / 'tools/ask_alpha_evaluation.py'),
                                   rust_binary_sha256=t.b.sha(ROOT / 'target/debug/verity'),
                                   inference_performed=False, executions=0))
    assert same, 'Registered score differs; preserve both results'
    assert all(r['matches_original_preview'] for r in rows if r['completed']), 'Preview replay differs'
    print('PASS: exact proposal-byte previews and registered model-free scoring reproduced', len(rows))


if __name__ == '__main__':
    main()
