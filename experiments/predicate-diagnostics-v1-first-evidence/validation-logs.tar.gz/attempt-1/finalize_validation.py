import gzip,hashlib,io,json,re,tarfile
from pathlib import Path
root=Path.cwd();report=root/'experiments/predicate-diagnostics-v1-first-evidence';first=root/'artifacts/predicate-native-first-evidence-validation';second=root/'artifacts/predicate-native-first-evidence-validation-2'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
full=read(second/'validation.json');verification=read(second/'checkout/artifacts/pre-llm/verification.json')
assert full['status']=='passed' and full['registered_binaries_unchanged']
assert verification['status']=='passed' and len(verification['commands'])==39
assert not verification['model_invoked'] and not verification['holdout_evaluated']
python_counts=list(map(int,re.findall(r'Ran (\d+) tests? in',(second/'checkout/artifacts/pre-llm/reporting-tests.stderr.txt').read_text())))
assert python_counts==[335,15]
rust=(second/'checkout/artifacts/pre-llm/rust-tests.stdout.txt').read_text()
rust_counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',rust)
assert rust_counts and all(int(failed)==int(ignored)==0 for _,failed,ignored in rust_counts)
for name,count in [('focused-tests',23),('evidence-tests',3)]:
 text=(first/(name+'.stderr.txt')).read_text();assert re.search(r'Ran '+str(count)+r' tests in',text) and text.rstrip().endswith('OK')
for name,expected in full['registered_binaries_before'].items():assert sha(root/name)==expected
payload={}
for prefix,base in [('attempt-1',first),('attempt-2',second)]:
 for p in sorted(base.iterdir()):
  if p.is_file():payload[prefix+'/'+p.name]=p.read_bytes()
 for p in sorted((base/'checkout/artifacts/pre-llm').rglob('*')):
  assert not p.is_symlink()
  if p.is_file():payload[prefix+'/pre-llm/'+str(p.relative_to(base/'checkout/artifacts/pre-llm'))]=p.read_bytes()
archive=report/'validation-logs.tar.gz'
with archive.open('xb') as target,gzip.GzipFile(fileobj=target,mode='wb',filename='',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as bundle:
 for name,raw in sorted(payload.items()):
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;bundle.addfile(info,io.BytesIO(raw))
manifest={name:hashlib.sha256(raw).hexdigest() for name,raw in sorted(payload.items())}
(report/'validation-logs-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
(report/'verification.json').write_bytes((second/'checkout/artifacts/pre-llm/verification.json').read_bytes())
record=dict(status='passed_after_model_free_timeout',validated_execution_commit=full['validated_commit'],full_pipeline_scope='Unchanged execution source; new evidence analyzer/tests validated separately. Existing trusted model-free fixture/oracle tests; generated model outputs are preview-only.',full_pipeline=full,full_pipeline_checks=len(verification['commands']),current_python_tests=python_counts[0],frozen_pilot_tests=python_counts[1],rust_tests=sum(int(n) for n,_,_ in rust_counts),focused_tests=23,evidence_tests=3,required_browsers=True,skips=False,earlier_pipeline_failure=read(first/'first-pipeline-failure.json'),failed_initial_pipeline_receipt_preserved=True,native_command_invocations=1,native_request_attempts=78,native_request_completions=77,native_failure='TimeoutError: timed out',native_unattempted=48,retries=0,original_byte_rust_replays=78,original_synthetic_rust_replays=124,model_generated_rdf_executions=0,validation_logs_archive_sha256=sha(archive),validation_logs_manifest_sha256=sha(report/'validation-logs-files.json'),validation_log_files=len(manifest),evidence_archive_sha256=sha(report/'evidence.tar.gz'),registered_binaries_unchanged=True,issue83='keep_open',issue75_integration='disabled',independent_human_review='deferred',decision='INCONCLUSIVE_REVISE')
(report/'validation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ['full_pipeline','earlier_pipeline_failure']},indent=2))
