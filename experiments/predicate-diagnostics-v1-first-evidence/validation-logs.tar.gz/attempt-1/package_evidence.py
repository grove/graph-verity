import gzip,hashlib,io,json,sys,tarfile
from pathlib import Path
sys.path.insert(0,'tools')
import predicate_diagnostics_native as n
root=Path.cwd(); report=root/'experiments/predicate-diagnostics-v1-first-evidence'
reg=n.read(n.REGISTRATION); frozen=n.verify(n.FREEZE,committed_registration=True)
state=n.read(n.OUTPUT/'run.json')
assert state['status']!='preparing' and n.read(n.OUTPUT/'checksums.json')==n.a.v.inventory(n.OUTPUT)
assert n.read(n.LEDGER)['registration_sha256']==n.sha(n.REGISTRATION)
payload={'registration.json':n.REGISTRATION.read_bytes(),'original-registration.json':(n.d.RELEASE/'registration.json').read_bytes(),'registered-freeze.tar.gz':(n.d.RELEASE/'freeze.tar.gz').read_bytes(),'attempt.json':n.LEDGER.read_bytes()}
for prefix,folder in [('run',n.OUTPUT),('freeze',n.FREEZE),('operator/initial-blocked-preflight',root/'artifacts/predicate-native-authorized-20261022-preflight'),('operator/admitted-preflight',root/'artifacts/predicate-native-authorized-20261022-preflight-2')]:
 for path in sorted(folder.rglob('*')):
  assert not path.is_symlink()
  if path.is_file():payload[prefix+'/'+str(path.relative_to(folder))]=path.read_bytes()
for name,expected in {**frozen['input_sha256'],**reg['input_sha256']}.items():
 raw=(root/name).read_bytes(); assert hashlib.sha256(raw).hexdigest()==expected
 payload['source/'+name]=raw
for name in ['analyze.py','test_analysis.py']:
 payload['analysis-source/'+name]=(report/name).read_bytes()
for name in ['execution-result.json','replay.json','source-audit-notes.json']:
 path=root/'artifacts/predicate-native-authorized-20261022-preflight-2'/name
 if path.exists():payload['operator/'+name]=path.read_bytes()
archive=report/'evidence.tar.gz'
with archive.open('xb') as target,gzip.GzipFile(fileobj=target,filename='',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as bundle:
 for name,raw in sorted(payload.items()):
  info=tarfile.TarInfo(name); info.size=len(raw); info.mode=0o644
  bundle.addfile(info,io.BytesIO(raw))
manifest=dict(archive_sha256=n.sha(archive),files={name:hashlib.sha256(raw).hexdigest() for name,raw in sorted(payload.items())})
n.dump(report/'evidence-files.json',manifest)
print(json.dumps(dict(files=len(payload),archive_bytes=archive.stat().st_size,archive_sha256=manifest['archive_sha256'],largest_member_bytes=max(map(len,payload.values())))))
