import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path.cwd()
base=root/'artifacts/predicate-native-first-evidence-validation-2'
checkout=base/'checkout'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
binaries=[root/'target/debug/verity',root/'target/debug/examples/v1g_preview']
before={str(p.relative_to(root)):sha(p) for p in binaries}
state=dict(status='running',validated_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),checkout=str(checkout),registered_binaries_before=before,model_loading_permitted=False,downloads_permitted=False,environment=dict(CARGO_NET_OFFLINE='true',REQUIRE_FIND_BROWSER='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1'),commands=[])
env={**os.environ,**state['environment']}
def save():
 (base/'validation.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 for label,args in [('isolated-build',['cargo','build','--locked','--offline','--bins','--examples']),('complete-pipeline',[str(checkout/'.venv/bin/python'),'-u','tools/verify_pre_llm.py'])]:
  started=time.monotonic()
  with (base/(label+'.stdout.txt')).open('x') as out,(base/(label+'.stderr.txt')).open('x') as err:
   result=subprocess.run(args,cwd=checkout,env=env,stdout=out,stderr=err)
  state['commands'].append(dict(label=label,args=args,returncode=result.returncode,elapsed_seconds=time.monotonic()-started))
  save()
  if result.returncode:
   state['status']='failed'
   save()
   raise ValueError(label+' failed')
 state['status']='passed'
finally:
 state['registered_binaries_after']={str(p.relative_to(root)):sha(p) for p in binaries}
 state['registered_binaries_unchanged']=state['registered_binaries_after']==before
 save()
 assert state['registered_binaries_unchanged']
