# Graph Verity oracle evaluation

Mode: `oracle_no_model`. Split: `dev`.

**46 / 46 checks passed.** Expected-abstention fixture bookkeeping is not parser accuracy.

Snapshot: `sha256:99e2dda9cf5408ed4b489f07782f18a22eeedd3422c822f3f225efcb26d6b97a`

| Case | Family | Stage | Pass |
|---|---|---|---|
| wd-dev-001 | entity_labels | scored | true |
| wd-dev-002 | direct_relation | scored | true |
| wd-dev-003 | inverse_relation | scored | true |
| wd-dev-004 | two_hop | scored | true |
| wd-dev-005 | date_lookup | scored | true |
| wd-dev-006 | entity_labels | scored | true |
| wd-dev-007 | direct_relation | scored | true |
| wd-dev-008 | inverse_relation | scored | true |
| wd-dev-009 | two_hop | scored | true |
| wd-dev-010 | date_lookup | scored | true |
| wd-dev-011 | entity_labels | scored | true |
| wd-dev-012 | direct_relation | scored | true |
| wd-dev-013 | inverse_relation | scored | true |
| wd-dev-014 | two_hop | scored | true |
| wd-dev-015 | date_lookup | scored | true |
| wd-dev-016 | entity_labels | scored | true |
| wd-dev-017 | direct_relation | scored | true |
| wd-dev-018 | inverse_relation | scored | true |
| wd-dev-019 | two_hop | scored | true |
| wd-dev-020 | date_lookup | scored | true |
| wd-dev-021 | numeric_comparison | scored | true |
| wd-dev-022 | numeric_comparison | scored | true |
| wd-dev-023 | numeric_comparison | scored | true |
| wd-dev-024 | numeric_comparison | scored | true |
| wd-dev-025 | numeric_comparison | scored | true |
| wd-dev-026 | numeric_comparison | scored | true |
| wd-dev-027 | date_comparison | scored | true |
| wd-dev-028 | date_comparison | scored | true |
| wd-dev-029 | date_comparison | scored | true |
| wd-dev-030 | date_comparison | scored | true |
| wd-dev-031 | distinct_count | scored | true |
| wd-dev-032 | distinct_count | scored | true |
| wd-dev-033 | grouping | scored | true |
| wd-dev-034 | having | scored | true |
| wd-dev-035 | having | scored | true |
| wd-dev-036 | conjunction_distinct_count | scored | true |
| wd-dev-037 | named_graph_scope | scored | true |
| wd-dev-038 | conjunction_numeric_date | scored | true |
| wd-dev-039 | ambiguous | fixture_status_only | true |
| wd-dev-040 | ambiguous | fixture_status_only | true |
| wd-dev-041 | unsupported | fixture_status_only | true |
| wd-dev-042 | unsupported | fixture_status_only | true |
| wd-dev-043 | unsupported | fixture_status_only | true |
| wd-dev-044 | unsupported | fixture_status_only | true |
| wd-dev-045 | unsupported | fixture_status_only | true |
| wd-dev-046 | unsupported | fixture_status_only | true |

See report.json for failures, exact set metrics, measured timings, hashes and limitations. No language model was run. Human gold review and independent holdout are still required.
