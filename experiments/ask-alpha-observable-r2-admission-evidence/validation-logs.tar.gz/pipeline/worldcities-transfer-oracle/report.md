# Graph Verity oracle evaluation

Mode: `oracle_no_model`. Split: `transfer_dev`.

**40 / 40 checks passed.** Expected-abstention fixture bookkeeping is not parser accuracy.

Snapshot: `sha256:b43faf6ee61a1b775a3837108331de59486dc232f0ab331dcd9934a8168e5601`

| Case | Family | Stage | Pass |
|---|---|---|---|
| gn-dev-001 | identity_label | scored | true |
| gn-dev-002 | direct_region | scored | true |
| gn-dev-003 | two_hop_country | scored | true |
| gn-dev-004 | inverse_region | scored | true |
| gn-dev-005 | distinct_city_count | scored | true |
| gn-dev-006 | group_having | scored | true |
| gn-dev-007 | numeric_identifier | scored | true |
| gn-dev-008 | identity_label | scored | true |
| gn-dev-009 | direct_region | scored | true |
| gn-dev-010 | two_hop_country | scored | true |
| gn-dev-011 | inverse_region | scored | true |
| gn-dev-012 | distinct_city_count | scored | true |
| gn-dev-013 | group_having | scored | true |
| gn-dev-014 | numeric_identifier | scored | true |
| gn-dev-015 | identity_label | scored | true |
| gn-dev-016 | direct_region | scored | true |
| gn-dev-017 | two_hop_country | scored | true |
| gn-dev-018 | inverse_region | scored | true |
| gn-dev-019 | distinct_city_count | scored | true |
| gn-dev-020 | group_having | scored | true |
| gn-dev-021 | numeric_identifier | scored | true |
| gn-dev-022 | identity_label | scored | true |
| gn-dev-023 | direct_region | scored | true |
| gn-dev-024 | two_hop_country | scored | true |
| gn-dev-025 | inverse_region | scored | true |
| gn-dev-026 | distinct_city_count | scored | true |
| gn-dev-027 | group_having | scored | true |
| gn-dev-028 | numeric_identifier | scored | true |
| gn-dev-029 | identity_label | scored | true |
| gn-dev-030 | direct_region | scored | true |
| gn-dev-031 | two_hop_country | scored | true |
| gn-dev-032 | inverse_region | scored | true |
| gn-dev-033 | distinct_city_count | scored | true |
| gn-dev-034 | group_having | scored | true |
| gn-dev-035 | numeric_identifier | scored | true |
| gn-dev-036 | missing_population | fixture_status_only | true |
| gn-dev-037 | open_world_negation | fixture_status_only | true |
| gn-dev-038 | subjective_criterion | fixture_status_only | true |
| gn-dev-039 | missing_ownership_domain | fixture_status_only | true |
| gn-dev-040 | ambiguous_largest | fixture_status_only | true |

See report.json for failures, exact set metrics, measured timings, hashes and limitations. No language model was run. Human gold review and independent holdout are still required.
