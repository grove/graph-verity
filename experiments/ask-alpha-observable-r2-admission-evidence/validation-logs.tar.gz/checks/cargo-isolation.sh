#!/bin/sh
# Frozen exports use their own disposable target paths; keep the main registered binary untouched.
case "$PWD" in
  /Users/grove/projects/graph-verity) export CARGO_TARGET_DIR=/Users/grove/projects/graph-verity/artifacts/ask-alpha-observable-r2-work/cargo-target ;;
  *) unset CARGO_TARGET_DIR ;;
esac
exec /opt/homebrew/bin/cargo "$@"
