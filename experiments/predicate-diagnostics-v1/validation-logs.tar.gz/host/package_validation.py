import gzip
import hashlib
import json
from pathlib import Path
import re
import sys
import tarfile

root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
import predicate_diagnostics as d
release = d.RELEASE
sandbox = root / 'artifacts/predicate-validation'
host = root / 'artifacts/predicate-validation-host'
logs = sandbox / 'checkout/artifacts/pre-llm'
state = d.read(host / 'full-pipeline-validation.json')
pipeline = d.read(logs / 'verification.json')
assert state['status'] == pipeline['status'] == 'passed'
assert state['registered_binary_unchanged']
assert pipeline['model_invoked'] is False and pipeline['holdout_evaluated'] is False
assert len(pipeline['commands']) == 39
reporting = (logs / 'reporting-tests.stderr.txt').read_text()
assert 'Ran 325 tests' in reporting and 'FAILED' not in reporting and 'OK (skipped=' not in reporting
rust = (logs / 'rust-tests.stdout.txt').read_text()
rust_count = sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed;', rust))
assert rust_count == 100
assert d.read(release / 'preservation.json')['all_preserved']
assert 'Ran 13 tests' in (root / 'artifacts/predicate-focused.stderr.txt').read_text()
assert '124 Rust previews reproduced' in (root / 'artifacts/predicate-replay.stdout.txt').read_text()
d.verify_registration(root / 'artifacts/predicate-diagnostics-v1')
entries = {}
for label, folder in [('sandbox', sandbox), ('host', host)]:
    for path in sorted(folder.glob('*')):
        if path.is_file():
            entries[label + '/' + path.name] = path
for label, folder in [('sandbox/pipeline', sandbox / 'sandbox-pre-llm'), ('host/pipeline', logs)]:
    for path in sorted(folder.rglob('*')):
        if path.is_file():
            entries[label + '/' + str(path.relative_to(folder))] = path
for name in ['predicate-focused.stdout.txt', 'predicate-focused.stderr.txt', 'predicate-replay.stdout.txt', 'predicate-replay.stderr.txt']:
    entries['focused/' + name] = root / 'artifacts' / name
archive = release / 'validation-logs.tar.gz'
with archive.open('xb') as stream, gzip.GzipFile(fileobj=stream, filename='', mode='wb', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as bundle:
        for name, path in sorted(entries.items()):
            info = bundle.gettarinfo(path, name)
            info.uid = info.gid = info.mtime = 0
            info.uname = info.gname = ''
            with path.open('rb') as content:
                bundle.addfile(info, content)
d.dump(release / 'validation-logs-files.json', dict(archive_sha256=d.sha(archive), files={n: d.sha(p) for n,p in sorted(entries.items())}))
counts = d.read(root / 'artifacts/predicate-diagnostics-v1/token-counts.json')['models']['qwen35']
d.dump(release / 'validation.json', dict(status='passed', validated_commit=state['validated_commit'],
    preparation_commit=d.read(release / 'registration.json')['freeze_manifest']['source_commit'],
    full_pipeline_checks=len(pipeline['commands']), full_pipeline=state, python_tests=325,
    frozen_pilot_tests=15, rust_tests=rust_count, focused_tests=13, grammar_controls=12,
    required_browsers=True, skips=False,
    sandbox_attempt=dict(status='failed_environment', python_tests=325, failures=8, errors=44,
                         reason='Sandbox denied loopback socket binding; unchanged host rerun passed'),
    registered_archive_sha256=d.sha(release / 'freeze.tar.gz'), tokenizer_observations=len(counts['rows']),
    maximum_input_plus_512_tokens=max(r['columnar']['total_required'] for r in counts['rows']),
    retained_native_parities_reproduced=len(counts['native_parities_reproduced']),
    new_request_native_parity='deferred_until_separate_explicit_model_loading_authorization',
    synthetic_rust_previews=124, synthetic_accepted=114, literal_range_reverse_empty_path_rejections=10,
    original_tracked_files_preserved=1342, historical_hashes_preserved=801,
    inference_performed=False, model_generated_rdf_executions=0, holdout_accessed=False,
    issue83='keep_open', issue75_integration='disabled', independent_human_review='deferred', decision='INCONCLUSIVE_REVISE',
    scope='Complete unchanged pipeline at registration commit; new receipt replay verifier independently exercised. Final evidence files do not change frozen preparation inputs.'))
d.dump(release / 'evidence-files.json', {str(p.relative_to(release)): d.sha(p) for p in sorted(release.rglob('*')) if p.is_file() and p.name != 'evidence-files.json'})
print('Packaged complete passed pipeline and failed sandbox attempt; no skips, inference or changed frozen inputs.')
