"""One-time packaging of original v1h bytes; run only after the registered attempt exits."""
import hashlib
import io
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path.cwd() / 'tools'))
import investigate_v1h as i

v = i.v
root = Path.cwd()
run = root / 'artifacts/issue83-v1h-budget-qwen35-first'
freeze = root / 'artifacts/v1h-budget'
report = root / 'experiments/native-one-hop-v1h-budget-qwen35-evidence'
readiness = root / 'artifacts/issue83-v1h-readiness-20261021T074056Z'
registration = v.read(v.RELEASE / 'registration.json')
frozen = v.verify_registration(freeze)
assert v.read(run / 'checksums.json') == v.a.v.inventory(run), 'Run inventory mismatch'
assert v.read(run / 'run.json')['model'] == 'qwen35'
assert not report.exists(), 'Never overwrite retained evidence'
assert v.read(root / ('artifacts/v1h-budget-attempts-' + v.sha(freeze / 'checksums.json') + '.json')) == ['qwen35']
payload = {}
for prefix, folder in [('freeze', freeze), ('run', run), ('readiness', readiness)]:
    for path in sorted(folder.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_file():
            payload[prefix + '/' + str(path.relative_to(folder))] = path.read_bytes()
for name, digest in frozen['input_sha256'].items():
    raw = (root / name).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == digest, name
    payload['source/' + name] = raw
supplemental = {}
for name in ['tools/analyze_v1f.py', 'tools/analyze_v1f_r3.py', 'tools/analyze_v1h_qwen.py', 'tools/test_analyze_v1h_qwen.py']:
    payload['source/' + name] = (root / name).read_bytes()
    supplemental[name] = v.sha(root / name)
payload['registration.json'] = (v.RELEASE / 'registration.json').read_bytes()
payload['authorization.json'] = (root / 'artifacts/issue83-v1h-budget-qwen35-authorization.json').read_bytes()
payload['operator/attempt-ledger.json'] = (root / ('artifacts/v1h-budget-attempts-' + v.sha(freeze / 'checksums.json') + '.json')).read_bytes()
payload['operator/package-evidence.py'] = Path(__file__).read_bytes()
payload['operator/execution-result.json'] = (root / 'artifacts/issue83-v1h-budget-qwen35-execution-result.json').read_bytes()
payload['operator/source-audit-notes.json'] = (root / 'artifacts/issue83-v1h-new-notes.json').read_bytes()
payload['operator/prior-source-investigation.json'] = (root / 'experiments/native-one-hop-v1h-investigation/generated/failure-by-failure.json').read_bytes()
assert all(len(raw) <= 16 * 1024 * 1024 for raw in payload.values()), 'Oversized evidence member'
report.mkdir()
i.write_archive(report / 'evidence.tar.gz', payload)
v.dump(report / 'evidence-files.json', dict(archive_sha256=v.sha(report / 'evidence.tar.gz'),
    files={n: hashlib.sha256(raw).hexdigest() for n, raw in sorted(payload.items())},
    supplemental_source_sha256=supplemental))
(report / 'authorization.json').write_bytes(payload['authorization.json'])
print(json.dumps(dict(report=str(report), original_files=len(payload), archive_sha256=v.sha(report / 'evidence.tar.gz')), indent=2))
