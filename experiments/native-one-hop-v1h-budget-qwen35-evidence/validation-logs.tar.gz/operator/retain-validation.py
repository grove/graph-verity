"""Retain both complete model-free validation attempts, including the first failure."""
import hashlib
import json
from pathlib import Path
import re
import sys

sys.path.insert(0, str(Path.cwd() / 'tools'))
import investigate_v1h as i

v = i.v
root = Path.cwd()
report = root / 'experiments/native-one-hop-v1h-budget-qwen35-evidence'
first = root / 'artifacts/issue83-v1h-qwen-validation'
second = root / 'artifacts/issue83-v1h-qwen-validation-2'
prellm = second / 'verification-checkout/artifacts/pre-llm'
verification = v.read(prellm / 'verification.json')
assert verification['status'] == 'passed'
assert v.read(second / 'validation-result.json')['registered_binary_unchanged']
assert len(verification['commands']) == 39
assert v.sha(v.a.BINARY) == '16744c50a0b1e89eca6374696e6004ca9782bff4ed59834a7e5ad97485f4b2db'
payload = {}
for number, folder in [(1, first), (2, second)]:
    for name in ['validation-result.json', 'isolated-build.stdout', 'isolated-build.stderr', 'complete-pipeline.stdout', 'complete-pipeline.stderr']:
        payload[f'attempt-{number}/' + name] = (folder / name).read_bytes()
    directory = folder / 'verification-checkout/artifacts/pre-llm'
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_file():
            payload[f'attempt-{number}/pre-llm/' + str(path.relative_to(directory))] = path.read_bytes()
for name in ['issue83-v1h-validate.py', 'issue83-v1h-validate-2.py', 'issue83-v1h-qwen-focused.stdout',
             'issue83-v1h-qwen-focused.stderr', 'issue83-v1h-qwen-replay.stdout', 'issue83-v1h-qwen-replay.stderr',
             'issue83-v1h-cold-cleanup-diagnostic.stdout', 'issue83-v1h-cold-cleanup-diagnostic.stderr']:
    payload['operator/' + name] = (root / 'artifacts' / name).read_bytes()
payload['operator/retain-validation.py'] = Path(__file__).read_bytes()
archive = report / 'validation-logs.tar.gz'
assert not archive.exists()
i.write_archive(archive, payload)
v.dump(report / 'validation-logs-files.json', dict(archive_sha256=v.sha(archive), files={n: hashlib.sha256(raw).hexdigest() for n, raw in sorted(payload.items())}))
(report / 'verification.json').write_bytes((prellm / 'verification.json').read_bytes())
state = v.read(report / 'validation.json')
state.update(status='passed', validated_commit=verification['git_commit'], full_pipeline_checks=len(verification['commands']),
    full_pipeline_environment=dict(CARGO_NET_OFFLINE='true', REQUIRE_FIND_BROWSER='1', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1'),
    current_python_tests=289, frozen_pilot_tests=15, rust_tests=100, required_browser_checks=True,
    complete_log_archive_sha256=v.sha(archive), original_registered_binary_unchanged=True,
    final_full_pipeline=v.read(second / 'validation-result.json'), inference_retries=0)
v.dump(report / 'validation.json', state)
historical = v.read(root / 'reports/issue-83-native-one-hop-v1f-diagnostic/historical-sha256.json')
assert len(historical) == 801 and all(v.sha(root / n) == digest for n, digest in historical.items())
frozen = v.verify_registration(root / 'artifacts/v1h-budget')
preservation = v.read(report / 'preservation.json')
preservation.update(post_full_pipeline_historical_hashes_verified=801, post_full_pipeline_registered_source_hashes_verified=len(frozen['input_sha256']),
    post_full_pipeline_binary_unchanged=True, inference_attempts=1)
v.dump(report / 'preservation.json', preservation)
v.dump(report / 'checksums.json', v.a.v.inventory(report))
print(json.dumps(dict(status=state['status'], pipeline_checks=len(verification['commands']), log_files=len(payload), log_archive_sha256=v.sha(archive)), indent=2))
