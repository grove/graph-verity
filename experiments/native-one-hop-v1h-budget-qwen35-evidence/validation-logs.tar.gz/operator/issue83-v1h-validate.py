"""Run the unchanged full model-free pipeline in a separate build tree, offline."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time

root = Path.cwd()
out = root / 'artifacts/issue83-v1h-qwen-validation'
checkout = out / 'verification-checkout'
assert not out.exists(), 'Use a fresh validation directory'
out.mkdir()
binary = root / 'target/debug/verity'
original = hashlib.sha256(binary.read_bytes()).hexdigest()
assert original == '16744c50a0b1e89eca6374696e6004ca9782bff4ed59834a7e5ad97485f4b2db'
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert subprocess.run(['git', 'diff', '--quiet', 'HEAD']).returncode == 0
archive = out / 'source.tar'
with archive.open('xb') as stream:
    subprocess.run(['git', 'archive', '--format=tar', commit], stdout=stream, check=True)
checkout.mkdir()
with tarfile.open(archive) as stream:
    stream.extractall(checkout, filter='data')
(checkout / '.git').symlink_to(root / '.git', target_is_directory=True)
(checkout / '.venv').symlink_to(root / '.venv', target_is_directory=True)
subprocess.run(['/bin/cp', '-cR', str(root / 'artifacts/issue83-v1h-investigation-20261021/verification-checkout/target'), str(checkout / 'target')], check=True)
env = dict(os.environ, GIT_DIR=str(root / '.git'), GIT_WORK_TREE=str(checkout),
    CARGO_NET_OFFLINE='true', REQUIRE_FIND_BROWSER='1', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
state = dict(validated_commit=commit, original_registered_binary_sha256=original,
    checkout=str(checkout), downloads_permitted=False, model_loading_permitted=False, commands=[])
try:
    for name, args in [('isolated-build', ['cargo', 'build', '--locked', '--offline', '--bins', '--examples']),
                       ('complete-pipeline', [str(checkout / '.venv/bin/python'), 'tools/verify_pre_llm.py'])]:
        started = time.monotonic()
        with (out / (name + '.stdout')).open('xb') as stdout, (out / (name + '.stderr')).open('xb') as stderr:
            result = subprocess.run(args, cwd=checkout, env=env, stdout=stdout, stderr=stderr)
        state['commands'].append(dict(name=name, args=args, returncode=result.returncode, elapsed_seconds=time.monotonic() - started))
        assert result.returncode == 0, name + ' failed; retain logs and stop'
    state['status'] = 'passed'
finally:
    state['original_registered_binary_after_sha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
    state['registered_binary_unchanged'] = state['original_registered_binary_after_sha256'] == original
    (out / 'validation-result.json').write_text(json.dumps(state, indent=2) + '\n')
    assert state['registered_binary_unchanged'], 'Original registered binary changed'
print(json.dumps(state, indent=2))
