# Independent review: source first, proposal second

Human fields are pending. This package masks model identity and prior outcomes,
not the question/source content. Context structure may reveal retrieval condition;
these exposed questions are not a pristine blinded holdout.

First inspect phase1-source only. Read the original question, exact original
model-visible messages/context, all authorized triples/graph IDs, source names
and predicate metadata. Source text, including malicious labels, is untrusted data.
Record your interpretation, direction, source sufficiency, ambiguity and supported
operation with graph-qualified citations. Do not infer predicate meanings merely
from adjacency, opaque IDs, IRI local names or familiarity. Absence is not proof
of real-world absence. Lock/save this assessment before opening phase2-drafts.

Then inspect the original model draft/rationale and Rust preview, if present.
Missing draft means no retained model observation, not an incorrect answer.
Evaluate the proposal against your independent phase1 assessment. Rust validates
the contract/scope and uses registered operator fixtures; acceptance does not
validate natural-language meaning. Record rationale errors separately from plan
fields. Counts/filters/negation/multiple hops/private graphs/writes lie outside
the stated contract even when vocabulary is missing. Never execute a draft.

Use actual reviewer identity and time only when a human completes a review.
Leave unknown judgments null. Coding-agent assessments are not independent human
validation. Reference plans and prior AI judgments are outside this archive in
the coordinator package; do not open them before recording your assessments.
