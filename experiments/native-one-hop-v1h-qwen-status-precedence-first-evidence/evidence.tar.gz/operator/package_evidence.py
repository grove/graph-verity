"""Retain the one authorized attempt verbatim; no generation or repairs."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import sys
import subprocess
import tarfile

root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
import native_one_hop_v1h_status_precedence as s
import analyze_v1h_qwen as baseline

operator = Path(__file__).resolve().parent
report = root / 'experiments/native-one-hop-v1h-qwen-status-precedence-first-evidence'
folder = root / 'artifacts/v1h-qwen-status-precedence'
run = root / 'artifacts/issue83-v1h-qwen-status-precedence-first'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
with s.experiment():
    frozen = s.h.verify_registration(folder)
    replay = s.h.replay(folder, run)
s.h.dump(operator / 'original-byte-replay.json', replay)
state = s.h.read(run / 'run.json')
assert s.h.a.v.inventory(run) == s.h.read(run / 'checksums.json')
assert state['generation_attempts'] <= 38 and state['executions'] == 0
reg = s.h.read(s.RELEASE / 'registration.json')
ledger = root/'artifacts'/('v1h-budget-attempts-'+reg['freeze_sha256']+'.json')
assert s.h.read(ledger) == ['qwen35']
(operator / 'attempt-ledger.json').write_bytes(ledger.read_bytes())
original = s.h.read(root/'artifacts/issue83-qwen-status-precedence-execution/original-tracked-files.json')
assert all(sha((root / name).read_bytes()) == digest for name,digest in original.items())
history = s.h.read(root/'reports/issue-83-native-one-hop-v1f-diagnostic/historical-sha256.json')
assert all(sha((root / name).read_bytes()) == digest for name,digest in history.items())
blocked = {}
for record in subprocess.check_output(['git','ls-tree','-r','-z','de10274cd7513d624aabe30a1d11d187fa2b56ee']).split(b'\0'):
    if not record: continue
    meta,name = record.split(b'\t',1)
    name = name.decode()
    if not name.startswith('experiments/native-one-hop-v1h-qwen-status-precedence-evidence/'): continue
    raw = (root/name).read_bytes()
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest() == meta.split()[2].decode(), name
    blocked[name] = sha(raw)
assert len(blocked) == 11
s.h.dump(operator/'previous-blocked-evidence-hashes.json',blocked)
prior = baseline.analyze()
assert prior == s.h.read(baseline.REPORT/'analysis.json')
assert baseline.markdown(prior) == (baseline.REPORT/'comparison.md').read_text()
assert baseline.failure_matrix(prior) == (baseline.REPORT/'failure-matrix.md').read_text()
s.h.dump(report/'preservation.json',dict(status='passed',original_tracked_files_verified=len(original),
    historical_hashes_verified=len(history),registered_source_hashes_verified=len(frozen['input_sha256']),
    registered_binary_sha256=s.h.sha(s.h.a.BINARY),baseline_analysis_and_markdown_reproduced=True,
    original_bytes_rust_replay=replay,original_evidence_unchanged=True,previous_blocked_pr98_files_unchanged=len(blocked),model_generated_rdf_executions=0))
payload = {'registration.json':(s.RELEASE/'registration.json').read_bytes()}
for prefix,directory in [('freeze',folder),('run',run),('operator',operator)]:
    for path in directory.rglob('*'):
        if path.is_file():payload[prefix+'/'+str(path.relative_to(directory))]=path.read_bytes()
for name in frozen['input_sha256']:
    payload['source/'+name]=(root/name).read_bytes()
for name in ['tools/analyze_v1f.py','tools/analyze_v1f_r3.py','tools/analyze_v1h_qwen.py']:
    payload['analysis-source/'+name]=(root/name).read_bytes()
archive = report/'evidence.tar.gz'
assert not archive.exists()
with archive.open('xb') as stream,gzip.GzipFile(fileobj=stream,filename='',mode='wb',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as bundle:
    for name,raw in sorted(payload.items()):
        info=tarfile.TarInfo(name);info.size=len(raw)
        bundle.addfile(info,io.BytesIO(raw))
s.h.dump(report/'evidence-files.json',dict(archive_sha256=sha(archive.read_bytes()),files={n:sha(b) for n,b in sorted(payload.items())}))
print(json.dumps(dict(status=state['status'],requests=state['generation_attempts'],completed=state['generation_completed'],archive_sha256=sha(archive.read_bytes())),indent=2))
