import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
import native_one_hop_v1h_swap2048 as v

out = ROOT / (ROOT / 'artifacts/issue83-v1h-gemma-evidence-validation-current.txt').read_text().strip()
checkout = out / 'verification-checkout'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
registered = v.verify(ROOT / 'artifacts/v1h-budget')
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
original_binary = ROOT / 'target/debug/verity'
state = dict(status='running', validated_commit=commit, checkout=str(checkout),
    original_registered_binary_sha256=sha(original_binary), model_loading_permitted=False,
    downloads_permitted=False, environment=dict(CARGO_NET_OFFLINE='true', REQUIRE_FIND_BROWSER='1',
        HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1'), commands=[])
def save():
    (out / 'full-pipeline-validation.json').write_text(json.dumps(state, indent=2)+'\n')
save()
checkout.mkdir()
archive = subprocess.check_output(['git', 'archive', commit], cwd=ROOT)
with tarfile.open(fileobj=io.BytesIO(archive)) as bundle:
    bundle.extractall(checkout, filter='data')
(checkout / '.git').symlink_to(ROOT / '.git', target_is_directory=True)
(checkout / '.venv').symlink_to(ROOT / '.venv', target_is_directory=True)
prior = ROOT / 'artifacts/issue83-v1h-swap2048-preparation-20261021T102800Z/verification-checkout/target'
subprocess.run(['cp', '-cR', str(prior), str(checkout / 'target')], check=True)
env = {**os.environ, **state['environment']}
try:
    for label, args in [('isolated-build', ['cargo', 'build', '--locked', '--offline', '--bins', '--examples']),
                        ('complete-pipeline', [str(checkout / '.venv/bin/python'), '-u', 'tools/verify_pre_llm.py'])]:
        started = time.monotonic()
        with (out / (label+'.stdout.txt')).open('w') as stdout, (out / (label+'.stderr.txt')).open('w') as stderr:
            result = subprocess.run(args, cwd=checkout, env=env, stdout=stdout, stderr=stderr)
        state['commands'].append(dict(label=label, args=args, returncode=result.returncode,
                                      elapsed_seconds=time.monotonic()-started))
        save()
        print(label, result.returncode, flush=True)
        if result.returncode:
            raise RuntimeError(label+' failed')
    v.verify(ROOT / 'artifacts/v1h-budget')
    state['status'] = 'passed'
except BaseException as error:
    state.update(status='failed', error=type(error).__name__+': '+str(error))
    raise
finally:
    state['original_registered_binary_after_sha256'] = sha(original_binary)
    state['registered_binary_unchanged'] = state['original_registered_binary_after_sha256'] == state['original_registered_binary_sha256']
    save()
print(json.dumps(state, indent=2), flush=True)
