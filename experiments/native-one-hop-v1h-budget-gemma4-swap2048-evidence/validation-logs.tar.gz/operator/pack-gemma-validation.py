"""Retain final model-free logs and preservation checks without changing native evidence."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
import compare_v1h_models as c
import native_one_hop_v1h_swap2048 as v

out = ROOT / (ROOT / 'artifacts/issue83-v1h-gemma-evidence-validation-current.txt').read_text().strip()
report = c.REPORT
checkout = out / 'verification-checkout'
driver = c.a.read(out / 'full-pipeline-validation.json')
receipt = c.a.read(checkout / 'artifacts/pre-llm/verification.json')
assert driver['status'] == receipt['status'] == 'passed'
assert driver['registered_binary_unchanged']
assert len(receipt['commands']) == 39
assert not receipt['model_invoked'] and not receipt['holdout_evaluated']
v.verify(ROOT / 'artifacts/v1h-budget')
history = c.a.read(ROOT / 'reports/issue-83-native-one-hop-v1f-diagnostic/historical-sha256.json')
assert len(history) == 801
for name, digest in history.items():
    assert c.a.digest((ROOT / name).read_bytes()) == digest, name
base = '5ee7354465e02ea5ac5ef03f296f7dd60ded7dab'
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(
        ['git', 'archive', base, '--', 'reports', 'experiments', 'studies'], cwd=ROOT))) as archive:
    retained = {m.name: archive.extractfile(m).read() for m in archive if m.isfile()}
assert len(retained) == 898
for name, raw in retained.items():
    assert (ROOT / name).read_bytes() == raw, name
assert c.analyze() == c.a.read(report / 'analysis.json')
files = {}
for path in sorted((checkout / 'artifacts/pre-llm').rglob('*')):
    if path.is_file() and (path.name.endswith(('.stdout.txt', '.stderr.txt')) or path.name == 'verification.json'):
        files['pre-llm/' + str(path.relative_to(checkout / 'artifacts/pre-llm'))] = path.read_bytes()
for name in ['full-pipeline-validation.json', 'isolated-build.stdout.txt', 'isolated-build.stderr.txt',
             'complete-pipeline.stdout.txt', 'complete-pipeline.stderr.txt']:
    files[name] = (out / name).read_bytes()
for path in [ROOT / 'artifacts/run-gemma-evidence-validation.py', Path(__file__)]:
    files['operator/' + path.name] = path.read_bytes()
summary = files['pre-llm/reporting-tests.stderr.txt'].decode()
test_runs = re.findall(r'Ran (\d+) tests in ([0-9.]+)s', summary)
assert [int(n) for n, _ in test_runs] == [297, 15], test_runs
assert not re.search(r'\bskipped\b', summary, re.I)
rust = files['pre-llm/rust-tests.stdout.txt'].decode()
rust_passed = sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed;', rust))
assert rust_passed == 100, rust_passed
archive = report / 'validation-logs.tar.gz'
assert not archive.exists()
with archive.open('xb') as target, gzip.GzipFile(fileobj=target, filename='', mode='wb', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as bundle:
        for name, raw in sorted(files.items()):
            member = tarfile.TarInfo(name)
            member.size, member.mode = len(raw), 0o644
            bundle.addfile(member, io.BytesIO(raw))
assert c.archive_files(archive) == files
dump = lambda p, x: p.write_text(json.dumps(x, ensure_ascii=False, indent=2)+'\n')
dump(report / 'validation-logs-files.json', dict(archive_sha256=c.a.digest(archive.read_bytes()),
    files={name: c.a.digest(raw) for name, raw in sorted(files.items())}))
dump(report / 'verification.json', receipt)
dump(report / 'validation.json', dict(status='passed', recorded_at=datetime.now(timezone.utc).isoformat(),
    validated_commit=driver['validated_commit'], full_pipeline_checks=39,
    current_python_tests=297, frozen_pilot_tests=15, python_tests_skipped=False, rust_tests=100,
    focused_comparison_tests=4, original_byte_rust_replay_previews=70,
    original_registered_source_hashes_verified=76, historical_hashes_verified=801,
    original_retained_files_match_merged_main=898, variant_source_hashes_verified=3,
    registered_binary_sha256=driver['original_registered_binary_after_sha256'],
    original_registration_resealed=False, original_binary_unchanged=True,
    complete_log_archive_sha256=c.a.digest(archive.read_bytes()), full_pipeline=driver,
    model_free_verification_inference=False, gemma_inference_command_exit_code=1,
    gemma_inference_attempts=1, inference_retries=0, model_generated_rdf_executions=0,
    semantic_decision='INCONCLUSIVE_REVISE', independent_human_review='deferred',
    issue83='keep_open', issue75_integration='disabled',
    scope='Exact candidate code/evidence validated; later additions are these validation receipts/logs and report checksum only.'))
dump(report / 'checksums.json', c.a.inventory(report))
print(json.dumps(c.a.read(report / 'validation.json'), indent=2))
