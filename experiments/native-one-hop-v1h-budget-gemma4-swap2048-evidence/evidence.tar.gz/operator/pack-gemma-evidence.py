"""Package the completed one-shot attempt; never invokes inference or overwrites evidence."""
import gzip
import io
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools'))
import compare_v1h_models as c
import native_one_hop_v1h_swap2048 as v

prep = Path(__file__).resolve().parent
auth = ROOT / Path((ROOT / 'artifacts/issue83-v1h-swap2048-authorization-current.txt').read_text().strip())
original_prep = ROOT / Path((ROOT / 'artifacts/issue83-v1h-gemma-preparation-current.txt').read_text().strip())
outer = ROOT / 'artifacts/issue83-v1h-budget-gemma4-swap2048-first'
freeze = ROOT / 'artifacts/v1h-budget'
report = c.REPORT
registered = v.verify(freeze)
assert (outer / 'checksums.json').exists(), 'Wait for the sole attempt to exit'
assert not report.exists(), 'Fresh evidence report directory required'
assert c.a.read(outer / 'variant-registration.json') == registered
assert {str(p.relative_to(outer)): c.a.digest(p.read_bytes()) for p in outer.rglob('*')
        if p.is_file() and p != outer / 'checksums.json'} == c.a.read(outer / 'checksums.json')
files = {}
timing = {}
for prefix, folder in [('variant', outer), ('freeze', freeze)]:
    for path in sorted(folder.rglob('*')):
        assert not path.is_symlink(), str(path)
        if path.is_file():
            name = prefix + '/' + str(path.relative_to(folder))
            files[name] = path.read_bytes()
            if prefix == 'variant':
                stat = path.stat()
                timing[name] = dict(bytes=stat.st_size, mtime_ns=stat.st_mtime_ns,
                                    ctime_ns=stat.st_ctime_ns, mode=stat.st_mode)
                if hasattr(stat, 'st_birthtime'):
                    timing[name]['birthtime_seconds'] = stat.st_birthtime
parent = c.a.read(v.h.RELEASE / 'registration.json')
source_names = set(parent['freeze_manifest']['input_sha256']) | set(registered['source_input_sha256'])
source_names.update(['tools/compare_v1h_models.py', 'tools/test_compare_v1h_models.py',
    'tools/analyze_v1f.py', 'tools/analyze_v1f_r3.py', 'tools/analyze_v1h_qwen.py',
    'tools/test_analyze_v1h_qwen.py', 'tools/compact_ab.py'])
for name in sorted(source_names):
    files['source/' + name] = (ROOT / name).read_bytes()
paths = {
    'registration.json': v.h.RELEASE / 'registration.json',
    'variant-registration.json': v.RELEASE / 'registration.json',
    'registered-freeze.tar.gz': v.h.RELEASE / 'freeze.tar.gz',
    'authorization.json': auth / 'authorization.json',
    'attempt-ledger.json': ROOT / 'artifacts' / ('v1h-budget-attempts-' + parent['freeze_sha256'] + '.json'),
    'operator/source-audit-notes.json': ROOT / 'artifacts/issue83-v1h-gemma-source-audit-notes.json',
    'operator/authorization-preflight.json': auth / 'host-preflight.json',
    'operator/authorization-preflight-original-1024.json': auth / 'host-preflight-original-1024.json',
    'operator/host-after-run.json': auth / 'host-after-run.json',
    'operator/host-after-run-original-1024.json': auth / 'host-after-run-original-1024.json',
    'operator/command-exit.json': auth / 'command-exit.json',
    'operator/command-output.txt': auth / 'command-output.txt',
    'operator/asset-verification-after-run.json': auth / 'asset-verification-after-run.json',
    'operator/original-byte-rust-replay.json': auth / 'original-byte-rust-replay.json',
    'operator/parent-preparation-verification.json': original_prep / 'post-verification-preservation.json',
    'operator/parent-asset-verification.json': original_prep / 'asset-verification.json',
    'operator/parent-budget-verification.json': original_prep / 'budget-verification.json',
    'operator/variant-preparation-verification.json': prep / 'verification-summary.json',
    'operator/variant-preparation-pipeline.json': prep / 'full-pipeline-validation.json',
    'operator/command-proposal.json': prep / 'operator-command-proposal.json',
    'operator/pack-gemma-evidence.py': Path(__file__),
}
for name, path in paths.items():
    files[name] = path.read_bytes()
files['operator/filesystem-timing.json'] = (json.dumps(dict(
    scope='Filesystem metadata observed at packaging, not independently authenticated operator timestamps.',
    files=timing), ensure_ascii=False, indent=2) + '\n').encode()
for name, digest in {**parent['freeze_manifest']['input_sha256'], **registered['source_input_sha256']}.items():
    assert c.a.digest(files['source/' + name]) == digest, name
assert not any(name.endswith(('.gguf', '.safetensors')) for name in files), 'Never package weights'
report.mkdir()
archive = report / 'evidence.tar.gz'
with archive.open('xb') as output, gzip.GzipFile(fileobj=output, filename='', mode='wb', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as bundle:
        for name, raw in sorted(files.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mode = len(raw), 0o644
            bundle.addfile(info, io.BytesIO(raw))
assert c.archive_files(archive) == files, 'Packaged bytes differ from original inputs'
v.h.dump(report / 'evidence-files.json', dict(archive_sha256=c.a.digest(archive.read_bytes()),
    files={name: c.a.digest(raw) for name, raw in sorted(files.items())}))
(report / 'authorization.json').write_bytes(files['authorization.json'])
print(json.dumps(dict(report=str(report), files=len(files), archive_sha256=c.a.digest(archive.read_bytes())), indent=2))
