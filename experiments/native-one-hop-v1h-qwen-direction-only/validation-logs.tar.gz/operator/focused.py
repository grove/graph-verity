import json,os,subprocess,sys,time
from pathlib import Path
root=Path.cwd();base=root/'artifacts/issue83-direction-validation'
env={**os.environ,'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','CARGO_NET_OFFLINE':'true'}
commands=[('direction-tests',[sys.executable,'-m','unittest','discover','-s','tools','-p','test_native_one_hop_v1h_direction.py','-v']),('predicate-audit',[sys.executable,'tools/audit_v1h_predicates.py','--check']),('qwen-baseline-analysis',[sys.executable,'experiments/native-one-hop-v1h-qwen-status-precedence-first-evidence/analyze.py','--check']),('gemma-comparison',[sys.executable,'tools/compare_v1h_models.py','--out',str(base/'gemma-comparison')])]
state=dict(status='running',validated_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),commands=[],inference_performed=False,executions=0)
for label,args in commands:
 start=time.monotonic()
 with (base/(label+'.stdout.txt')).open('w') as out,(base/(label+'.stderr.txt')).open('w') as err:
  result=subprocess.run(args,cwd=root,env=env,stdout=out,stderr=err)
 state['commands'].append(dict(label=label,args=args,returncode=result.returncode,elapsed_seconds=time.monotonic()-start))
 assert result.returncode==0,label
state['status']='passed';(base/'focused.json').write_text(json.dumps(state,indent=2)+'\n')
