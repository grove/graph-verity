import hashlib,json,subprocess,sys,tarfile
from pathlib import Path
sys.path.insert(0,'tools')
import native_one_hop_v1h_direction as v
h=v.h
root=Path.cwd();out=root/'artifacts/issue83-direction-validation'
base='82e81a3e30c315c27d86b5c125143020a172af18'
digest=lambda b:hashlib.sha256(b).hexdigest()
files=[]
process=subprocess.Popen(['git','archive',base],stdout=subprocess.PIPE)
with tarfile.open(fileobj=process.stdout,mode='r|') as archive:
 for member in archive:
  if member.isfile():
   files.append(member.name)
   assert h.sha(root/member.name)==digest(archive.extractfile(member).read()),member.name
assert process.wait()==0
history=h.read(root/'reports/issue-83-native-one-hop-v1f-diagnostic/historical-sha256.json')
assert len(history)==801
for name,value in history.items():assert h.sha(root/name)==value,name
records=[]
for name in files:
 if not (name.startswith('experiments/') and name.endswith('/registration.json')):continue
 path=root/name; reg=h.read(path)
 if 'archive_sha256' not in reg and 'source_input_sha256' not in reg:
  for source,value in reg['input_sha256'].items():assert h.sha(root/source)==value,source
  records.append(dict(path=name,sha256=h.sha(path),design_only=True,source_hashes=len(reg['input_sha256'])))
  continue
 if 'archive_sha256' not in reg:
  for source,value in reg['source_input_sha256'].items():assert h.sha(root/source)==value,source
  records.append(dict(path=name,sha256=h.sha(path),variant=True,source_hashes=len(reg['source_input_sha256']),parent_archive_sha256=reg['parent_freeze_archive_sha256']))
  continue
 archive=path.parent/'freeze.tar.gz';assert h.sha(archive)==reg['archive_sha256'],name
 payload=h.a.g.archive_files(archive)
 assert {n:digest(b) for n,b in payload.items() if n!='checksums.json'}==json.loads(payload['checksums.json']),name
 frozen=json.loads(payload['freeze.json']);assert frozen==reg['freeze_manifest'],name
 source=frozen['source_commit']
 for source_name,value in frozen['input_sha256'].items():
  assert digest(subprocess.check_output(['git','show',source+':'+source_name]))==value,(name,source_name)
 if 'freeze_sha256' in reg:assert digest(payload['checksums.json'])==reg['freeze_sha256'],name
 records.append(dict(path=name,sha256=h.sha(path),archive_sha256=reg['archive_sha256'],source_commit=source,source_hashes=len(frozen['input_sha256']),binary_sha256=frozen['binary_sha256']))
with v.experiment():
 frozen=h.verify_registration(root/'artifacts/v1h-qwen-direction-only')
 assets=h.a.assets(out/'assets.json')
 assert {k:assets[k] for k in frozen['runtime_identity']}==frozen['runtime_identity']
 assert not (root/h.config()['proposed_output']).exists()
 ledger=root/'artifacts'/('v1h-budget-attempts-'+h.sha(root/'artifacts/v1h-qwen-direction-only/checksums.json')+'.json')
 assert not ledger.exists()
 binary=h.sha(h.a.BINARY);assert binary==frozen['binary_sha256']
h.dump(out/'preservation.json',dict(status='passed',base_commit=base,original_tracked_files_verified=len(files),historical_hashes_verified=len(history),historical_registrations=records,new_source_hashes_verified=len(frozen['input_sha256']),registered_binary_sha256=binary,pinned_assets_match=True,new_output_absent=True,new_attempt_ledger_absent=True,ledger_path=str(ledger.relative_to(root)),inference_performed=False,executions=0,independent_human_review='pending'))
print('Preserved',len(files),'original files,',len(history),'historical hashes and',len(records),'historical registrations; pinned assets and binary match.')
