import gzip,hashlib,io,json,re,sys,tarfile
from pathlib import Path
sys.path.insert(0,'tools')
import native_one_hop_v1h_direction as v
h=v.h;root=h.ROOT;base=root/'artifacts/issue83-direction-validation';release=v.RELEASE
pipeline=h.read(base/'full-pipeline-validation.json');assert pipeline['status']=='passed',pipeline
verification=h.read(base/'verification-checkout/artifacts/pre-llm/verification.json');assert verification['status']=='passed'
focused=h.read(base/'focused.json');assert focused['status']=='passed'
preservation=h.read(base/'preservation.json');assert preservation['status']=='passed'
replay=h.read(base/'replay-tokenizer.json');assert replay['status']=='passed'
reg=h.read(release/'registration.json')
assert pipeline['registered_binary_unchanged']
assert pipeline['original_registered_binary_after_sha256']==h.sha(h.a.BINARY)==reg['freeze_manifest']['binary_sha256']
logs={}
for path in base.glob('*'):
 if path.is_file() and path.suffix in ['.txt','.py','.json']:
  logs['operator/'+path.name]=path.read_bytes()
for attempt in ['sandbox-attempt','host-attempt-1']:
 for path in (base/attempt).rglob('*'):
  if path.is_file():logs[attempt+'/'+str(path.relative_to(base/attempt))]=path.read_bytes()
for path in (base/'verification-checkout/artifacts/pre-llm').glob('*'):
 if path.is_file():logs['pre-llm/'+path.name]=path.read_bytes()
for path in (base/'native-grammar-controls').rglob('*'):
 if path.is_file():logs['native-grammar-controls/'+str(path.relative_to(base/'native-grammar-controls'))]=path.read_bytes()
for path in (root/'artifacts/v1h-qwen-direction-only-recount').rglob('*'):
 if path.is_file():logs['independent-tokenizer-recount/'+str(path.relative_to(root/'artifacts/v1h-qwen-direction-only-recount'))]=path.read_bytes()
for name in ['analysis.json','comparison.md','failure-matrix.md']:
 assert (base/'gemma-comparison'/name).read_bytes()==(root/'experiments/native-one-hop-v1h-budget-gemma4-swap2048-evidence'/name).read_bytes()
reporting=logs['pre-llm/reporting-tests.stderr.txt'].decode()
python_counts=[int(n) for n in re.findall(r'Ran (\d+) tests',reporting)]
rust=logs['pre-llm/rust-tests.stdout.txt'].decode()
rust_count=sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed',rust))
assert 'skipped=' not in reporting and not re.search(r'\.\.\. skipped',reporting)
assert len(verification['commands'])==39 and python_counts==[312,15] and rust_count==100,(python_counts,rust_count)
receipt=dict(status='passed',validated_commit=pipeline['validated_commit'],source_commit=reg['freeze_manifest']['source_commit'],
 registered_revision=reg['version'],registration_sha256=h.sha(release/'registration.json'),archive_sha256=reg['archive_sha256'],freeze_sha256=reg['freeze_sha256'],
 exact_command='REQUIRE_FIND_BROWSER=1 .venv/bin/python tools/verify_pre_llm.py',full_pipeline_checks=len(verification['commands']),python_test_counts=python_counts,rust_tests=rust_count,focused_direction_tests=8,python_tests_skipped=False,required_browser_checks=True,
 full_pipeline=pipeline,focused=focused,replay_tokenizer=replay,preservation=preservation,
 initial_host_attempt=dict(status='failed',current_python_tests=312,passed=311,errors=1,reason='Existing local_find no-JavaScript browser condition timed out. Isolated unchanged check passed in 8.428s; full unchanged pipeline rerun. All attempts retained.',log_prefix='host-attempt-1/'),initial_sandbox_attempt=dict(status='failed',current_python_tests=312,failures=8,errors=44,reason='Sandbox denied localhost socket binding; unchanged model-free pipeline rerun with host execution. Full original logs retained.',log_prefix='sandbox-attempt/'),new_inference=False,model_generated_rdf_executions=0,independent_human_review='pending',decision='INCONCLUSIVE_REVISE',issue83='keep_open',issue75_integration='disabled',
 native_parity_scope='Pinned tokenizer reproduces 36 retained historical native records. New prompts recounted twice offline; fresh native server parity is mandatory per future generation and was not performed because model loading is unauthorized.',
 validation_scope='All source and registration bytes tested at c0fa7de20edfacada8aa5e3bb7fa9e7d323282b9 in isolated checkout; later commit adds only these validation receipts, logs and preservation receipts.',
 future_authorization_command='.venv/bin/python tools/native_one_hop_v1h_direction.py run --freeze artifacts/v1h-qwen-direction-only --model qwen35 --allow-inference --out artifacts/issue83-v1h-qwen-direction-only-first')
h.dump(release/'validation.json',receipt)
h.dump(release/'preservation.json',preservation)
archive=release/'validation-logs.tar.gz'
with archive.open('xb') as stream,gzip.GzipFile(fileobj=stream,filename='',mode='wb',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
 for name,raw in sorted(logs.items()):
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;tar.addfile(info,io.BytesIO(raw))
h.dump(release/'validation-logs-files.json',dict(archive_sha256=h.sha(archive),files={name:hashlib.sha256(raw).hexdigest() for name,raw in sorted(logs.items())}))
h.dump(release/'checksums.json',h.a.v.inventory(release))
print(json.dumps({k:receipt[k] for k in ['status','validated_commit','full_pipeline_checks','python_test_counts','rust_tests']}))
