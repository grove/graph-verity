import json,sys,tempfile
from pathlib import Path
sys.path.insert(0,'tools')
import native_one_hop_v1h_direction as v
h=v.h;out=h.ROOT/'artifacts/issue83-direction-validation'
records={}
for name in ['native-one-hop-v1h-budget-qwen35-evidence','native-one-hop-v1h-qwen-status-precedence-first-evidence','native-one-hop-v1h-budget-gemma4-swap2048-evidence']:
 archive=h.ROOT/'experiments'/name/'evidence.tar.gz';payload=h.a.g.archive_files(archive)
 prefix='variant/run/' if 'gemma4' in name else 'run/'
 saved=[n for n in payload if n.startswith(prefix) and n.endswith('/rust.json')]
 for member in saved:
  parent=member.removesuffix('/rust.json')
  with tempfile.TemporaryDirectory() as temp:
   folder=Path(temp);raw=folder/'proposal.txt';raw.write_bytes(payload[parent+'/proposal.txt'])
   actual=h.a.preview_raw(json.loads(payload[parent+'/context.json']),raw,folder,json.loads(payload[parent+'/catalog.json']))
   assert actual==json.loads(payload[member]),member
 records[name]=dict(rust_previews=len(saved),archive_sha256=h.sha(archive))
with v.experiment():
 h.a.grammar_controls(h.read(h.ROOT/'artifacts/v1h-qwen-direction-only/contexts/eva-07-oracle.json'),out/'native-grammar-controls')
 h.replay(h.ROOT/'artifacts/v1h-qwen-direction-only')
original=h.read(h.ROOT/'artifacts/v1h-qwen-direction-only/tokenization/counts.json')
recount=h.read(h.ROOT/'artifacts/v1h-qwen-direction-only-recount/counts.json')
assert original['python']==recount['python'] and original['packages']==recount['packages']
for old,new in zip(original['models']['qwen35']['rows'],recount['models']['qwen35']['rows']):
 for variant in ['original','columnar']:
  assert {k:value for k,value in old[variant].items() if k!='section_contributions'}==new[variant]
rows=original['models']['qwen35']['rows']
h.dump(out/'replay-tokenizer.json',dict(status='passed',replays=records,native_grammar_controls=12,independent_recount_exact=True,prompts=38,semantic=36,native_history_parities=len(original['models']['qwen35']['native_parities_reproduced']),max_columnar_input=max(r['columnar']['input_tokens'] for r in rows),max_columnar_total=max(r['columnar']['total_required'] for r in rows),max_original_input=max(r['original']['input_tokens'] for r in rows),output_reserve=512,context=16384,inference_performed=False,executions=0))
print(records)
