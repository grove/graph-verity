import gzip,hashlib,json,re,tarfile
from pathlib import Path
root=Path.cwd()
b=root/'artifacts/issue83-qwen-status-precedence-validation'
r=root/'experiments/native-one-hop-v1h-qwen-status-precedence'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
state=read(b/'full-pipeline-validation.json')
assert state['status']=='passed'
checkout=b/'verification-checkout'
pipeline=read(checkout/'artifacts/pre-llm/verification.json')
assert pipeline['status']=='passed' and not pipeline['model_invoked'] and not pipeline['holdout_evaluated']
report=(checkout/'artifacts/pre-llm/reporting-tests.stderr.txt').read_text()
assert 'Ran 304 tests' in report and 'Ran 15 tests' in report
assert not re.search(r'\bskipped\b',report)
assert len(pipeline['commands'])==39
assert state['registered_binary_unchanged']
paths={}
for name in ['full-pipeline-validation.json','isolated-build.stdout.txt','isolated-build.stderr.txt','complete-pipeline.stdout.txt','complete-pipeline.stderr.txt','qwen-original-byte-replay.json','gemma-original-byte-replay.json','run_validation.py','verify_history.py','package_receipts.py']:
 paths['host-validation/'+name]=b/name
for prefix,folder in [('host-validation/pre-llm',checkout/'artifacts/pre-llm'),('sandbox-attempt',b/'sandbox-attempt'),('native-grammar-controls',b/'native-grammar-controls')]:
 for p in sorted(folder.rglob('*')):
  if p.is_file():paths[prefix+'/'+str(p.relative_to(folder))]=p
# Keep verification logs and receipts, not derived RDF/oracle artifacts or executable files.
paths={n:p for n,p in paths.items() if p.suffix in ['.txt','.json','.py','.stdout','.stderr','.gbnf']}
archive=r/'validation-logs.tar.gz'
with archive.open('xb') as out,gzip.GzipFile(fileobj=out,filename='',mode='wb',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as bundle:
 for name,p in sorted(paths.items()):
  info=bundle.gettarinfo(p,name);info.mtime=info.uid=info.gid=0;info.uname=info.gname=''
  with p.open('rb') as src:bundle.addfile(info,src)
(r/'validation-logs-files.json').write_text(json.dumps(dict(archive_sha256=sha(archive),files={n:sha(p) for n,p in sorted(paths.items())}),indent=2)+'\n')
sandbox=read(b/'sandbox-attempt/full-pipeline-validation.json')
validation=dict(status='passed',validated_commit=state['validated_commit'],full_pipeline_checks=39,current_python_tests=304,frozen_pilot_tests=15,rust_tests=100,focused_status_precedence_tests=7,python_tests_skipped=False,required_browser_checks=True,native_grammar_controls=12,independent_recount_exact_bytes_and_token_ids=True,original_byte_rust_replay_previews=dict(qwen=74,gemma=70),historical_hashes_verified=801,parent_source_hashes_verified=76,new_source_hashes_verified=83,baseline_retained_files_verified=942,pinned_assets_match_original_registration=True,registered_binary_unchanged=True,registered_binary_sha256=state['original_registered_binary_sha256'],inference_performed=False,inference_attempts=0,inference_retries=0,model_generated_rdf_executions=0,decision='INCONCLUSIVE_REVISE',independent_human_review='deferred',issue83='keep_open',issue75_integration='disabled',full_pipeline=state,initial_sandbox_attempt=dict(status='failed',current_python_tests=304,failures=8,errors=44,cause='Sandbox denied loopback socket binding and process inspection (EPERM); no experiment source change. Complete host-permission rerun passed.',full_pipeline=sandbox),complete_log_archive_sha256=sha(archive),scope='Exact final source/registration candidate validated; subsequent additions are model-free receipts/logs only.')
(r/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
(r/'verification.json').write_bytes((checkout/'artifacts/pre-llm/verification.json').read_bytes())
print(json.dumps({k:v for k,v in validation.items() if k not in ['full_pipeline','initial_sandbox_attempt']},indent=2))
