import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path.cwd()
base=root/'artifacts/issue83-qwen-status-precedence-validation'
checkout=base/'verification-checkout'
binary=root/'target/debug/verity'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
state=dict(status='running',validated_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),checkout=str(checkout),original_registered_binary_sha256=sha(binary),model_loading_permitted=False,downloads_permitted=False,environment=dict(CARGO_NET_OFFLINE='true',REQUIRE_FIND_BROWSER='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1'),commands=[])
env={**os.environ,**state['environment']}
def save():(base/'full-pipeline-validation.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 for label,args in [('isolated-build',['cargo','build','--locked','--offline','--bins','--examples']),('complete-pipeline',[str(checkout/'.venv/bin/python'),'-u','tools/verify_pre_llm.py'])]:
  start=time.monotonic()
  with (base/(label+'.stdout.txt')).open('w') as out,(base/(label+'.stderr.txt')).open('w') as err:
   p=subprocess.run(args,cwd=checkout,env=env,stdout=out,stderr=err)
  state['commands'].append(dict(label=label,args=args,returncode=p.returncode,elapsed_seconds=time.monotonic()-start))
  save()
  if p.returncode:raise ValueError(label+' failed')
 state['status']='passed'
except BaseException as e:
 state.update(status='failed',error=type(e).__name__+': '+str(e))
 raise
finally:
 state.update(original_registered_binary_after_sha256=sha(binary),registered_binary_unchanged=sha(binary)==state['original_registered_binary_sha256'])
 save()
