import hashlib,json,subprocess
from pathlib import Path
root=Path.cwd()
base='5cd33d5ab2098510f6e78bf6d97ef6b9fe2de2a1'
release=root/'experiments/native-one-hop-v1h-qwen-status-precedence'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checked={}
for record in subprocess.check_output(['git','ls-tree','-r','-z',base]).split(b'\0'):
 if not record:continue
 meta,name=record.split(b'\t',1)
 name=name.decode()
 if not name.startswith(('experiments/','reports/','configs/','studies/')):continue
 raw=(root/name).read_bytes()
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==meta.split()[2].decode(),name
 checked[name]=hashlib.sha256(raw).hexdigest()
history=json.loads((root/'reports/issue-83-native-one-hop-v1f-diagnostic/historical-sha256.json').read_bytes())
for name,digest in history.items():assert sha(root/name)==digest,name
parent=json.loads((root/'experiments/native-one-hop-v1h-budget/registration.json').read_bytes())
for name,digest in parent['freeze_manifest']['input_sha256'].items():assert sha(root/name)==digest,name
reg=json.loads((release/'registration.json').read_bytes())
for name,digest in reg['freeze_manifest']['input_sha256'].items():assert sha(root/name)==digest,name
assert sha(root/'target/debug/verity')==parent['freeze_manifest']['binary_sha256']
recount=json.loads((root/'artifacts/v1h-qwen-status-precedence-recount/counts.json').read_bytes())
frozen=json.loads((root/'artifacts/v1h-qwen-status-precedence/tokenization/counts.json').read_bytes())
for x,y in zip(recount['models']['qwen35']['rows'],frozen['models']['qwen35']['rows']):
 for variant in ['original','columnar']:
  for key in ['tokens','prompt','input_tokens','output_reserve','total_required','fits','tokens_sha256','prompt_sha256']:
   assert x[variant][key]==y[variant][key],(x['name'],variant,key)
for folder,new in [('native-one-hop-v1h-budget-qwen35-evidence','qwen-reanalysis'),('native-one-hop-v1h-budget-gemma4-swap2048-evidence','qwen-gemma-reanalysis')]:
 for name in ['analysis.json','comparison.md','failure-matrix.md']:
  assert (root/'experiments'/folder/name).read_bytes()==(root/'artifacts/issue83-qwen-status-precedence-validation'/new/name).read_bytes(),(folder,name)
summary=dict(status='passed',baseline_commit=base,baseline_retained_files_verified=len(checked),historical_hashes_verified=len(history),parent_source_hashes_verified=len(parent['freeze_manifest']['input_sha256']),new_source_hashes_verified=len(reg['freeze_manifest']['input_sha256']),registered_binary_sha256=sha(root/'target/debug/verity'),independent_recount_exact_prompt_and_token_ids_match=True,baseline_qwen_and_gemma_analysis_reproduced=True,previous_reports_or_experiments_modified=False,holdout_accessed=False,inference_performed=False,inference_attempts=0,model_generated_rdf_executions=0,files=checked)
(release/'preservation.json').write_text(json.dumps(summary,indent=2)+'\n')
print({k:v for k,v in summary.items() if k!='files'})
